# Run State Contract

```json
{
  "run_id": "",
  "operator": "",
  "requested_target": "Ascend310",
  "architecture": "DaVinci",
  "required_backend": "CCE-C",
  "cann_version": null,
  "cce_compiler": null,
  "detected_soc": null,
  "current_stage": "NEW",
  "stages": {},
  "final_status": "IN_PROGRESS"
}
```

The orchestrator owns this state. Stage subagents may report facts but should not silently rewrite upstream verdicts.
