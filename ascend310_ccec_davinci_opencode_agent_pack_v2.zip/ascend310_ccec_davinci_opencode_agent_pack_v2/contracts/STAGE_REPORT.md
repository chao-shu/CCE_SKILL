# Stage Report Contract

Every delegated stage must emit a machine-readable JSON report with at least:

```json
{
  "run_id": "",
  "stage": "",
  "status": "PASS|FAIL|BLOCKED|NOT_RUN",
  "inputs": [],
  "input_hashes": {},
  "outputs": [],
  "evidence": [],
  "assumptions": [],
  "warnings": [],
  "blockers": [],
  "failure_class": null,
  "recommended_next_stage": null
}
```

`PASS` requires evidence. `NOT_RUN` can never be interpreted as `PASS`.
