# KB Evidence Contract

`kb_evidence.json` must preserve provenance and compatibility.

Each selected evidence item should include:

```json
{
  "id": "",
  "kind": "api|golden|pattern|failure|performance|official|project",
  "trust": "T0|T1|T2|T3|T4|T5|T6",
  "soc": ["Ascend310"],
  "architecture": ["DaVinci"],
  "cann": [],
  "backend": ["cce-c"],
  "source": "",
  "verification": [],
  "compatibility": "EXACT|PROVEN_COMPATIBLE|CONCEPT_ONLY|UNKNOWN",
  "usable_for_codegen": false,
  "notes": ""
}
```

Only evidence explicitly marked `usable_for_codegen=true` may establish an intrinsic/signature/constraint for production code.
