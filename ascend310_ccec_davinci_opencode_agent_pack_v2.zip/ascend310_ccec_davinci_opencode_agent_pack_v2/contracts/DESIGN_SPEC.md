# DaVinci / CCE-C Design Contract

`design.json` is implementation-ready hardware mapping for original Ascend 310.

Minimum sections:

```json
{
  "target": {
    "soc": "Ascend310",
    "architecture": "DaVinci",
    "backend": "CCE-C"
  },
  "operator_family": "",
  "core_partition": {},
  "memory_plan": {
    "gm": [],
    "ub": [],
    "l1": [],
    "l0": [],
    "workspace": []
  },
  "tiling": {},
  "data_movement": [],
  "vector_plan": {},
  "cube_plan": {},
  "pipeline_plan": [],
  "event_plan": [],
  "tail_plan": {
    "core_tail": {},
    "tile_tail": {},
    "dma_tail": {},
    "vector_mask_tail": {}
  },
  "numerical_mapping": {},
  "api_intrinsic_plan": [],
  "unverified_assumptions": [],
  "expected_bottlenecks": []
}
```

Every UB/L1/L0 allocation must include byte offset/size/alignment when known and a live range. Overlap is allowed only when live ranges prove it safe.

Every event/flag must identify producer pipeline, consumer pipeline, event ID selection rule and reuse point.
