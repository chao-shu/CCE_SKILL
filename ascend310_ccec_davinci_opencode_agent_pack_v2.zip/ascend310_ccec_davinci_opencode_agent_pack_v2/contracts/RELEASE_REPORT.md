# Release Report Contract

Final report must state:

```json
{
  "target": "Ascend310",
  "architecture": "DaVinci",
  "backend": "CCE-C",
  "SEMANTICS": "PASS|FAIL|BLOCKED|NOT_RUN",
  "DESIGN": "PASS|FAIL|BLOCKED|NOT_RUN",
  "BUILD": "PASS|FAIL|BLOCKED|NOT_RUN",
  "ACCURACY": "PASS|FAIL|BLOCKED|NOT_RUN",
  "BOARD": "PASS|FAIL|BLOCKED|NOT_RUN",
  "PERFORMANCE": "PASS|FAIL|BLOCKED|NOT_RUN",
  "REGRESSION": "PASS|FAIL|BLOCKED|NOT_RUN",
  "FINAL": "PASS|FAIL|BLOCKED"
}
```

`BOARD=NOT_RUN` forbids claims such as “verified on Ascend 310 hardware”.
