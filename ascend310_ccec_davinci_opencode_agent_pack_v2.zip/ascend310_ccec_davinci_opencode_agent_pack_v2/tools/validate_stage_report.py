#!/usr/bin/env python3
import argparse,json,sys
p=argparse.ArgumentParser(); p.add_argument('path'); a=p.parse_args()
obj=json.load(open(a.path,encoding='utf-8'))
required=['stage','status']
missing=[k for k in required if k not in obj]
if missing:
 print('FAIL missing:', ','.join(missing)); sys.exit(1)
if obj['status'] not in {'PASS','FAIL','BLOCKED','NOT_RUN'}:
 print('FAIL invalid status:',obj['status']); sys.exit(1)
print('PASS')
