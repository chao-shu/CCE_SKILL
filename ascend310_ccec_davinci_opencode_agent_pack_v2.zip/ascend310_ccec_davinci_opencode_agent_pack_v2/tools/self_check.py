#!/usr/bin/env python3
from pathlib import Path
import re, json, subprocess, sys, tempfile
root=Path(__file__).resolve().parents[1]
problems=[]
skill_root=root/'.opencode/skills'
skills=[]
for d in sorted(skill_root.iterdir()):
    if not d.is_dir(): continue
    p=d/'SKILL.md'
    if not p.exists():
        problems.append(f'missing {p.relative_to(root)}'); continue
    text=p.read_text(encoding='utf-8')
    m=re.search(r'^name:\s*([^\n]+)$',text,re.M)
    name=m.group(1).strip().strip('"\'') if m else None
    if name!=d.name: problems.append(f'name mismatch: {d.name} != {name}')
    if re.search(r'target:\s*["\']?Ascend 310P|target:\s*["\']?Ascend310P',text):
        problems.append(f'310P target residue in {p.relative_to(root)}')
    skills.append(name)
if len(skills)!=15: problems.append(f'expected 15 skills, got {len(skills)}')

lint=subprocess.run([sys.executable,str(root/'tools/kb_lint.py'),'--knowledge',str(root/'knowledge')],capture_output=True,text=True)
if lint.returncode!=0: problems.append('KB lint failed: '+lint.stdout+lint.stderr)

result={'ok':not problems,'skill_count':len(skills),'problems':problems}
print(json.dumps(result,indent=2,ensure_ascii=False))
raise SystemExit(0 if not problems else 1)
