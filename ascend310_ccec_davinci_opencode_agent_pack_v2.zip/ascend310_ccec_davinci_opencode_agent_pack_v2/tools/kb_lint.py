#!/usr/bin/env python3
"""Lightweight linter for Markdown KB cards. Standard library only."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

REQUIRED = ["id", "kind", "title", "status", "soc", "architecture", "cann", "backend", "trust", "source"]
VALID_STATUS = {"PROVISIONAL", "VERIFIED", "QUARANTINED", "DEPRECATED"}
VALID_TRUST = {"T0", "T1", "T2", "T3", "T4", "T5", "T6"}


def parse(text: str) -> dict[str, str]:
    if not text.startswith("---\n"):
        return {}
    end = text.find("\n---\n", 4)
    if end < 0:
        return {}
    result: dict[str, str] = {}
    for line in text[4:end].splitlines():
        if ":" in line and not line.lstrip().startswith("#"):
            k, v = line.split(":", 1)
            result[k.strip()] = v.strip().strip('"\'')
    return result


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--knowledge", default="knowledge")
    args = p.parse_args()
    problems = []
    seen: dict[str, str] = {}
    for path in sorted(Path(args.knowledge).rglob("*.md")):
        if "_templates" in path.parts or path.name.lower() in {"readme.md", "index.md"}:
            continue
        meta = parse(path.read_text(encoding="utf-8"))
        if not meta:
            problems.append({"path": str(path), "error": "missing frontmatter"})
            continue
        missing = [k for k in REQUIRED if not meta.get(k)]
        if missing:
            problems.append({"path": str(path), "error": f"missing fields: {missing}"})
        if meta.get("status") and meta["status"] not in VALID_STATUS:
            problems.append({"path": str(path), "error": f"invalid status {meta['status']}"})
        if meta.get("trust") and meta["trust"] not in VALID_TRUST:
            problems.append({"path": str(path), "error": f"invalid trust {meta['trust']}"})
        card_id = meta.get("id")
        if card_id:
            if card_id in seen:
                problems.append({"path": str(path), "error": f"duplicate id also in {seen[card_id]}"})
            else:
                seen[card_id] = str(path)
    print(json.dumps({"ok": not problems, "problems": problems}, indent=2, ensure_ascii=False))
    return 1 if problems else 0


if __name__ == "__main__":
    raise SystemExit(main())
