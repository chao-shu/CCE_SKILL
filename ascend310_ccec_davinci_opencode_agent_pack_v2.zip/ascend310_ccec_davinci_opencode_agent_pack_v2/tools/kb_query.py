#!/usr/bin/env python3
"""Query the local KB SQLite index with compatibility filters before text ranking."""
from __future__ import annotations

import argparse
import json
import sqlite3
from pathlib import Path


def add_filter(where: list[str], params: list[str], column: str, value: str | None) -> None:
    if not value:
        return
    # Pipe-separated indexed arrays. ANY/UNKNOWN remain candidates but rank below exact outside this simple helper.
    where.append(f"({column} = ? OR {column} LIKE ? OR {column} LIKE ? OR {column} LIKE ? OR {column} LIKE '%ANY%' OR {column} LIKE '%UNKNOWN%')")
    params.extend([value, f"{value}|%", f"%|{value}", f"%|{value}|%"])


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("query")
    p.add_argument("--db", default=".operator-agent/kb.sqlite")
    p.add_argument("--soc")
    p.add_argument("--architecture")
    p.add_argument("--cann")
    p.add_argument("--compiler")
    p.add_argument("--backend")
    p.add_argument("--usable-for-codegen", choices=["true", "false"])
    p.add_argument("--family")
    p.add_argument("--dtype")
    p.add_argument("--layout")
    p.add_argument("--status", default="VERIFIED,PROVISIONAL")
    p.add_argument("--limit", type=int, default=20)
    args = p.parse_args()

    db = Path(args.db)
    if not db.exists():
        raise SystemExit(f"KB index not found: {db}. Run tools/kb_index.py first.")
    conn = sqlite3.connect(db)
    conn.row_factory = sqlite3.Row

    where: list[str] = []
    params: list[str] = []
    statuses = [s.strip() for s in args.status.split(",") if s.strip()]
    if statuses:
        where.append("status IN (%s)" % ",".join("?" for _ in statuses))
        params.extend(statuses)

    add_filter(where, params, "soc", args.soc)
    add_filter(where, params, "architecture", args.architecture)
    add_filter(where, params, "cann", args.cann)
    add_filter(where, params, "compiler", args.compiler)
    add_filter(where, params, "backend", args.backend)
    if args.usable_for_codegen is not None:
        where.append("lower(usable_for_codegen) = ?")
        params.append(args.usable_for_codegen)
    add_filter(where, params, "op_family", args.family)
    add_filter(where, params, "dtype", args.dtype)
    add_filter(where, params, "layout", args.layout)

    where_sql = " AND ".join(where) if where else "1=1"

    # Prefer FTS5 when available, then fall back to LIKE.
    fts_exists = conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='docs_fts'").fetchone()
    rows = []
    if fts_exists:
        try:
            sql = f"""
                SELECT d.*, bm25(docs_fts) AS text_score
                FROM docs_fts
                JOIN docs d ON d.rowid = docs_fts.rowid
                WHERE docs_fts MATCH ? AND {where_sql}
                ORDER BY text_score ASC
                LIMIT ?
            """
            rows = conn.execute(sql, [args.query, *params, args.limit]).fetchall()
        except sqlite3.OperationalError:
            rows = []

    if not rows:
        terms = [t for t in args.query.replace('"', ' ').split() if t]
        text_clause = " AND ".join("(title LIKE ? OR body LIKE ? OR tags LIKE ?)" for _ in terms) or "1=1"
        text_params: list[str] = []
        for t in terms:
            like = f"%{t}%"
            text_params.extend([like, like, like])
        sql = f"SELECT *, 0 AS text_score FROM docs WHERE {where_sql} AND {text_clause} LIMIT ?"
        rows = conn.execute(sql, [*params, *text_params, args.limit]).fetchall()

    trust_rank = {"T0": 0, "T1": 1, "T2": 2, "T3": 3, "T4": 4, "T5": 5, "T6": 6}
    result = [dict(r) for r in rows]
    result.sort(key=lambda r: (trust_rank.get(r.get("trust", "T6"), 99), r.get("text_score", 0)))
    for r in result:
        r.pop("body", None)
    print(json.dumps(result[: args.limit], indent=2, ensure_ascii=False))
    conn.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
