#!/usr/bin/env python3
from pathlib import Path
import argparse, json, datetime, re

p=argparse.ArgumentParser()
p.add_argument('--operator', required=True)
p.add_argument('--target', default='Ascend310')
p.add_argument('--architecture', default='DaVinci')
p.add_argument('--backend', default='CCE-C')
a=p.parse_args()
slug=re.sub(r'[^A-Za-z0-9_.-]+','-',a.operator).strip('-') or 'operator'
ts=datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
run_id=f'{ts}_{slug}'
run=Path('.operator-agent/runs')/run_id
run.mkdir(parents=True, exist_ok=False)
state={
 'run_id':run_id,'operator':a.operator,'requested_target':a.target,
 'architecture':a.architecture,'required_backend':a.backend,
 'cann_version':None,'cce_compiler':None,'detected_soc':None,
 'current_stage':'NEW','stages':{},'final_status':'IN_PROGRESS'
}
(run/'state.json').write_text(json.dumps(state,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(run)
