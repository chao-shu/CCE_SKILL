---
name: ascend310-ccec-accuracy-validation
description: Independently validate an Ascend 310 CCE-C kernel against the Python oracle across semantic, dtype, multicore, DMA, vector-mask and tiling boundaries and classify mismatches to the correct upstream owner.
compatibility: opencode
metadata:
  target: "Ascend 310"
  backend: "CCE-C"
  stage: "accuracy"
---

# Preconditions

`BUILD == PASS`.

# Mission

Prove semantic correctness independently from code generation.

Instantiate the approved `test_plan.json`, using verified design constants for hardware-boundary cases.

# Required checks

For integer/boolean/index/data-movement semantics use exact equality where appropriate.

For floating point record at least:

- max absolute error;
- max relative error;
- mean absolute error;
- mismatch count;
- first/top mismatch indices;
- NaN mismatch;
- Inf mismatch.

# Hardware-boundary diagnosis

When failures cluster around a boundary, inspect specifically:

- core quotient/remainder;
- GM per-core offset;
- tile final length;
- DMA aligned length vs valid length;
- GM overread/overwrite;
- UB offset overlap;
- vector mask on final repeat;
- repeat count/stride;
- missing or incorrect flag/wait/barrier;
- event ID reuse race;
- dtype conversion/accumulation.

# Failure classes

- `SEMANTIC_ERROR`
- `CORE_PARTITION_ERROR`
- `DMA_TAIL_ERROR`
- `DMA_STRIDE_ERROR`
- `UB_MEMORY_ERROR`
- `VECTOR_MASK_ERROR`
- `VECTOR_REPEAT_STRIDE_ERROR`
- `PIPELINE_SYNC_ERROR`
- `EVENT_REUSE_ERROR`
- `CUBE_MAPPING_ERROR`
- `DTYPE_ERROR`
- `PRECISION_ERROR`
- `KERNEL_LOGIC_ERROR`
- `UNKNOWN_ERROR`

Do not loosen tolerance simply to get PASS.

# Output

Write `RUN_DIR/accuracy_report.json` with per-case evidence and recommended upstream stage.

Profiling is prohibited while accuracy is not PASS.
