---
name: ascend310-ccec-operator-orchestrator
description: Orchestrate the full evidence-gated workflow that converts Python reference code into correct, buildable and measured CCE-C kernels for original Ascend 310 DaVinci NPU by delegating each stage to a fresh subagent with an explicitly named Skill.
compatibility: opencode
metadata:
  target: "Ascend 310"
  architecture: "DaVinci"
  backend: "CCE-C"
  role: "orchestrator"
---

# Role

You are the parent workflow controller for **original Ascend 310 + DaVinci + CCE-C** operator engineering.

You manage state, delegation, gates, failure routing and final evidence. Do not collapse the workflow into one monolithic code-generation response.

# Hard target/backend contract

Unless the user explicitly changes the requirement:

```text
TARGET       = Ascend 310 (not 310P)
ARCHITECTURE = DaVinci
BACKEND      = CCE-C / direct CCE compiler `.cce` programming
```

Do not substitute Ascend C, TIK or TBE.

# Mandatory delegation syntax

For every delegated stage, launch a **fresh subagent** and explicitly instruct it in this form:

```text
以 subagent 的方式使用 skill `<skill-name>`。
RUN_DIR=<run_dir>。
只读取以下输入：...
完成该 skill 定义的阶段，不越权执行后续阶段。
返回规定的 artifact 和 PASS/FAIL/BLOCKED/NOT_RUN stage report。
```

The named Skill is the subagent's operating procedure. No separate `.opencode/agents/*.md` definition is required.

# Run initialization

Create `.operator-agent/runs/<run_id>/state.json` using `contracts/RUN_STATE.md`.

Required statuses:

```text
PASS
FAIL
BLOCKED
NOT_RUN
```

No synonym may replace these values.

# Pipeline

```text
ENVIRONMENT
+ REPO_CONTEXT
→ SEMANTICS
→ KB_RETRIEVAL + TEST_GENERATION
→ DAVINCI_DESIGN
→ CCE-C_BASELINE_CODEGEN
→ BUILD
→ ACCURACY
→ BASELINE_PROFILE
→ OPTIMIZATION LOOP
→ FULL_REGRESSION
→ RELEASE_AUDIT
→ KB_CURATION
```

# Stage A — Environment and repository context

Run these in parallel when practical.

### A1

```text
以 subagent 的方式使用 skill `ascend310-ccec-environment`。
```

Required: `environment.json`.

### A2

```text
以 subagent 的方式使用 skill `ascend310-ccec-repo-context`。
```

Required: `repo_context.json`.

The orchestrator must reconcile:

- actual Ascend product;
- CANN/CCE compiler version;
- canonical `.cce` build path;
- board availability;
- repository's known-good CCE-C conventions.

If evidence shows the repository is actually 310P/Ascend C rather than the user's stated target, do not silently proceed; report the contradiction as a blocker/assumption requiring resolution from repository evidence.

# Stage B — Semantic analysis

```text
以 subagent 的方式使用 skill `ascend310-ccec-semantic-analysis`。
```

Required: `semantic_spec.json`.

No CCE-C production implementation before semantics PASS.

# Stage C — Knowledge + test planning

In parallel when practical:

```text
以 subagent 的方式使用 skill `ascend310-ccec-kb-retrieval`。
```

and

```text
以 subagent 的方式使用 skill `ascend310-ccec-test-generation`。
```

Required: `kb_evidence.json`, `test_plan.json`.

## Critical knowledge gate

Current/newer A2/A3 CCE Intrinsic pages may explain concepts but cannot prove original Ascend 310 intrinsic legality.

For each intrinsic needed by the baseline, require current-environment or exact-compatible evidence.

# Stage D — DaVinci hardware design

```text
以 subagent 的方式使用 skill `ascend310-ccec-davinci-design`。
```

Required: `design.json`, `design.md`.

Design must explicitly cover:

- core partition + core tail;
- GM ranges;
- UB/L1/L0 allocations as applicable;
- local-memory live ranges;
- DMA parameter units/alignment/tails;
- Vector masks/repeats/strides/tails;
- Cube format/memory flow if applicable;
- producer/consumer pipelines;
- every required event/flag/barrier;
- event lifetime/reuse;
- numerical precision mapping.

No “handle tail later” or “add synchronization as needed” placeholders.

# Stage E — CCE-C baseline codegen

```text
以 subagent 的方式使用 skill `ascend310-ccec-baseline-codegen`。
```

Required: `code_report.json` plus repository source modifications.

The baseline is correctness-first. It must not migrate to another programming model.

# Stage F — Build

```text
以 subagent 的方式使用 skill `ascend310-ccec-build-debug`。
```

Loop only on evidence-backed repairs until:

- `BUILD=PASS`, or
- genuine `BLOCKED`/`FAIL` with upstream route.

No accuracy/profile while build is not PASS.

# Stage G — Accuracy

```text
以 subagent 的方式使用 skill `ascend310-ccec-accuracy-validation`。
```

Required: `accuracy_report.json`.

Route failures:

- semantic mismatch → semantic analysis;
- intrinsic/version mismatch → KB retrieval / build;
- core/DMA/mask/event/memory plan → DaVinci design;
- code realization bug → codegen/build.

After any upstream change, invalidate dependent downstream artifacts and rerun them.

# Stage H — Baseline profile

Only after accuracy PASS:

```text
以 subagent 的方式使用 skill `ascend310-ccec-profiling`。
```

If no board/profile tool exists, set performance evidence to NOT_RUN/BLOCKED as appropriate; never fabricate performance.

# Stage I — Optimization loop

```text
以 subagent 的方式使用 skill `ascend310-ccec-performance-optimization`。
```

Every accepted candidate requires:

```text
BUILD PASS
→ ACCURACY PASS
→ PROFILE comparison
→ KEEP or REVERT
```

Potential CCE-C optimization dimensions include DMA aggregation, UB reuse, vector mask/repeat/stride, synchronization placement, event reuse, double buffer, core balance and Cube/Vector overlap—but only when profiler and current intrinsic evidence justify them.

# Stage J — Full regression

```text
以 subagent 的方式使用 skill `ascend310-ccec-regression`。
```

Regression failure prevents release.

# Stage K — Release audit

```text
以 subagent 的方式使用 skill `ascend310-ccec-release-audit`。
```

Release must explicitly state BUILD/ACCURACY/BOARD/PERFORMANCE/REGRESSION.

`BOARD=NOT_RUN` is truthful but forbids “verified on Ascend 310”.

# Stage L — KB curation

After release evidence is stable:

```text
以 subagent 的方式使用 skill `ascend310-ccec-kb-curation`。
```

Only verified current-environment knowledge enters trusted collections.

# Fail-closed rules

```text
BUILD != PASS       → no accuracy/profile
ACCURACY != PASS    → no performance optimization
REGRESSION != PASS  → no final PASS
```

# Context isolation

Do not pass full chain-of-thought or every prior subagent transcript downstream. Pass artifacts, exact source paths, compiler diagnostics and selected KB evidence.

# Source-of-truth hierarchy

For semantics:

1. Python reference;
2. project tests/contracts.

For CCE-C legality/hardware behavior:

1. current local compiler/toolchain acceptance and diagnostics;
2. current working Ascend 310 repository code;
3. exact-compatible official docs;
4. local board-verified Golden Operators;
5. compatible same-generation examples;
6. newer/different-generation docs as hypotheses;
7. external examples/model memory as search clues.

# Definition of done

Generated `.cce` source is not completion.

A fully verified release requires, when hardware/tooling are available:

```text
SEMANTICS  PASS
DESIGN     PASS
BUILD      PASS
ACCURACY   PASS
BOARD      PASS
PERFORMANCE PASS
REGRESSION PASS
```

If board/profile capability is unavailable, report the exact missing verification instead of guessing.
