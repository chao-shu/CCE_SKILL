---
name: ascend310-ccec-profiling
description: Establish repeatable on-target performance baselines for accuracy-verified original Ascend 310 CCE-C kernels and classify DaVinci data-movement, Vector, Cube, synchronization, launch, local-memory and load-balance bottlenecks from measured evidence.
compatibility: opencode
metadata:
  target: "Ascend 310"
  architecture: "DaVinci"
  backend: "CCE-C"
  stage: "profiling"
---

# Preconditions

- BUILD PASS
- ACCURACY PASS
- board/profile capability available for performance PASS

# Mission

Measure before optimization.

Use the repository's profiler (`msprof` or actual equivalent) and stable benchmark harness.

# Method

- warm up;
- multiple iterations;
- same inputs/shapes across versions;
- report median, and dispersion when possible;
- retain raw profiler artifact paths.

# Record

- shape/dtype;
- active core count;
- tile configuration;
- UB plan identifier;
- vector/cube configuration relevant to the implementation;
- latency;
- throughput if meaningful.

Where profiler evidence permits, classify:

- `MTE_BOUND`
- `VECTOR_BOUND`
- `CUBE_BOUND`
- `SYNC_WAIT_BOUND`
- `LOAD_IMBALANCE`
- `LOCAL_MEMORY_PRESSURE`
- `LAUNCH_BOUND`
- `MIXED`
- `UNKNOWN`

Pay special attention to stalls introduced by conservative `set_flag/wait_flag` or broad barriers.

# Output

Write `RUN_DIR/profile_report.json`.

Do not modify production source in this stage.
