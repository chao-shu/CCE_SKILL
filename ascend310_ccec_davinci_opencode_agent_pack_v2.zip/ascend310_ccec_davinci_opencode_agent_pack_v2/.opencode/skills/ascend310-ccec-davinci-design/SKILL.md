---
name: ascend310-ccec-davinci-design
description: Design a correctness-first low-level DaVinci AI Core execution plan for an original Ascend 310 CCE-C kernel, including core partitioning, GM/UB/L1/L0 memory, DMA, vector/cube intrinsics, explicit pipeline synchronization, event lifecycle, masks, strides and safe tails.
compatibility: opencode
metadata:
  target: "Ascend 310"
  architecture: "DaVinci"
  backend: "CCE-C"
  stage: "hardware design"
---

# Mission

Translate approved semantics into a **direct CCE-C / DaVinci AI Core execution design**. Do not write production kernel code yet.

# Backend invariant

The output backend is `CCE-C`.

Do not propose `AscendC::`, `TPipe`, `TQue`, TIK DSL or TBE DSL as the implementation path unless the user explicitly changes requirements.

# Operator family

Classify as applicable:

- pure Vector / elementwise;
- reduction;
- broadcast/indexing;
- transpose/reformat;
- Cube/matrix;
- mixed Cube + Vector;
- memory-bound transform;
- other.

# Core partition

Design:

- active AI Core count using only verified platform/project limits;
- logical work per core;
- verified block-index mechanism;
- quotient/remainder distribution;
- per-core GM offsets;
- zero-work core prevention;
- core-tail behavior.

Never assume total work divides evenly by the number of cores.

# Memory hierarchy plan

For every live buffer, record as applicable:

- GM source/destination range;
- UB allocation byte offset and byte size;
- L1/CBUF allocation when required;
- L0A/L0B/L0C or other local memory only if verified by this environment;
- alignment requirement and evidence;
- producer/consumer pipeline;
- live range;
- overlap/reuse proof.

If exact UB/L1/L0 capacity is unknown, obtain it from current evidence or defer the size choice. Never hardcode a remembered value.

# Data movement plan

For every movement identify:

- source/destination address space;
- intrinsic candidate and evidence ID;
- length unit (bytes/blocks/elements/etc.) from evidence;
- burst count/length/stride meaning;
- alignment constraints;
- whether tail transfer can be performed safely;
- whether padding is part of the public storage contract;
- whether a temporary UB tail path is required.

**Never overread or overwrite GM simply to round to a transfer granularity unless the memory contract proves the padded region is valid.**

# Vector plan

When Vector instructions are used, design and verify:

- vector mask mode;
- mask for full chunks;
- mask for final valid elements;
- repeat count;
- src/dst repeat stride;
- block stride;
- overlap restrictions;
- dtype-specific lane behavior;
- required `set_vector_mask` / mask-mode setup if applicable;
- pipeline type (`PIPE_V` or actual verified equivalent).

Every mask/repeat/stride value must be derived, not copied blindly from another operator.

# Cube plan

When Cube is used, explicitly design only from verified current-generation evidence:

- GM→L1/CBUF movement;
- format/fractal conversion requirements;
- L1→L0A/L0B movement;
- Cube/MAD execution;
- accumulation type;
- L0C output path;
- Cube↔Vector handoff when present;
- relevant MTE/Cube pipelines and synchronization.

Do not import A2/A3 matrix formats/intrinsics unless proven compatible.

# Pipeline and event plan

Build an explicit dependency graph.

For each instruction group record its pipeline, such as the actual verified equivalents of:

- GM→UB memory-transfer pipeline;
- Vector pipeline;
- UB→GM memory-transfer pipeline;
- L1/L0 movement pipelines;
- Cube pipeline.

For each cross-pipeline dependency specify:

```text
producer pipeline
consumer pipeline
event/flag ID
set point
wait point
safe reuse point
```

Rules:

- no buffer may be consumed before producing DMA/compute finishes;
- no buffer may be overwritten before all consumers finish;
- an event ID may not be reused while a previous dependency using it is live;
- barriers must be justified by dependency, not inserted everywhere defensively;
- double buffering requires a buffer/event state machine proof.

# Tail proof

Separate four tails:

1. core remainder;
2. tile remainder;
3. DMA/alignment remainder;
4. vector-mask remainder.

A design is incomplete if any applicable tail is described only as “handle tail”.

# Numerical mapping

Map Python precision to:

- load dtype;
- compute dtype;
- accumulation dtype;
- conversion instructions;
- output dtype;
- expected rounding/error mechanisms.

# Baseline principle

The baseline should favor the simplest provably correct schedule. Double buffer, aggressive event choreography, deep UB reuse and shape specialization are optional optimization candidates unless required by the repository architecture.

# Outputs

Write:

- `RUN_DIR/design.json`
- `RUN_DIR/design.md`

using `contracts/DESIGN_SPEC.md`.

PASS requires explicit core/tile/DMA/vector tails, memory-liveness proof, pipeline/event proof, and no unresolved API legality required for baseline codegen.
