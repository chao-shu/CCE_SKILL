---
name: ascend310-ccec-kb-retrieval
description: Retrieve trust-ranked, version-compatible CCE-C/DaVinci evidence for original Ascend 310, prioritizing current compiler and locally verified kernels while preventing contamination from newer SoC CCE Intrinsic examples.
compatibility: opencode
metadata:
  target: "Ascend 310"
  backend: "CCE-C"
  stage: "knowledge retrieval"
---

# Mission

Retrieve only evidence relevant to the actual Ascend 310 CCE-C environment.

Inputs:

- `environment.json`
- `repo_context.json`
- `semantic_spec.json`

# Mandatory hard filters

Before semantic similarity, filter/rank by:

1. exact target `Ascend310`;
2. exact or proven-compatible CANN/CCE compiler generation;
3. backend `cce-c`;
4. DaVinci generation/product compatibility;
5. operator family;
6. dtype/layout when relevant.

# Trust ladder

- T0: current local compiler/build/disassembly evidence;
- T1: current repository code that compiles/runs on this Ascend 310 setup;
- T2: exact-version official Ascend 310 CCE/CCE-C documentation;
- T3: board-verified local Golden Operator;
- T4: same-generation official example or generated CCE-C with compatibility evidence;
- T5: newer/different SoC official CCE Intrinsic documentation;
- T6: external material or model memory.

T5/T6 are **never** API-legality proof.

# Retrieve evidence for

- kernel declaration/entry conventions;
- address-space keywords;
- data movement intrinsic signatures and units;
- Vector/Cube instruction signatures;
- vector mask/repeat/stride semantics;
- pipeline type for each intrinsic;
- event/barrier rules;
- UB/L1/L0 allocation and alignment constraints;
- multicore/block index mechanism;
- datatype support;
- known compiler bugs/failures;
- similar verified kernels;
- measured performance cases.

# Output

Write `RUN_DIR/kb_evidence.json` following `contracts/KB_EVIDENCE.md`.

Every API/intrinsic intended for code generation must have `usable_for_codegen=true` and a concrete provenance path.
