---
name: ascend310-ccec-release-audit
description: Audit all Ascend 310 CCE-C workflow evidence, final diff, build/accuracy/board/performance/regression results, API provenance and unsupported cases to issue a fail-closed release verdict without modifying production code.
compatibility: opencode
metadata:
  target: "Ascend 310"
  backend: "CCE-C"
  stage: "release audit"
---

# Mission

Issue the final truthfully scoped verdict.

Verify:

- target is original Ascend 310;
- final backend is CCE-C;
- no accidental Ascend C/TIK/TBE migration occurred;
- every nontrivial intrinsic/signature used has acceptable evidence;
- source diff matches approved design;
- BUILD status;
- ACCURACY status;
- BOARD status;
- PERFORMANCE status;
- REGRESSION status;
- unsupported dtype/shape/domain list;
- unresolved assumptions.

If board execution did not occur, `BOARD=NOT_RUN` and wording must not claim hardware verification.

If performance profiling did not occur, do not claim the kernel is optimized merely because the code uses double buffering or vector intrinsics.

Write `RUN_DIR/release_report.json` according to `contracts/RELEASE_REPORT.md`.
