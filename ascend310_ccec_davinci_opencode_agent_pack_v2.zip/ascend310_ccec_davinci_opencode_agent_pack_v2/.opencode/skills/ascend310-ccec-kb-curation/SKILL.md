---
name: ascend310-ccec-kb-curation
description: Promote verified original Ascend 310 CCE-C compiler/API, Golden Operator, DaVinci pipeline, failure and measured performance knowledge into provenance-rich Markdown cards while quarantining unverified cross-generation claims.
compatibility: opencode
metadata:
  target: "Ascend 310"
  backend: "CCE-C"
  stage: "knowledge curation"
---

# Mission

Turn completed engineering evidence into durable local knowledge without poisoning the KB.

# Card types

- `API`
- `GOLDEN_OPERATOR`
- `PATTERN`
- `FAILURE`
- `PERFORMANCE`
- `PROJECT_CONVENTION`
- `OFFICIAL_REFERENCE`

# Promotion rules

## API card

May become `VERIFIED` when at least one strong current-environment proof exists, preferably:

- current CCE compiler accepts the exact signature for the target;
- and/or current repository build proves it;
- plus board evidence where runtime behavior matters.

## Golden Operator

Requires at least:

- clean build PASS;
- accuracy PASS;
- Ascend 310 board PASS.

Performance need not be optimal.

## Performance card

Must record exact:

- target/product;
- CANN/CCE compiler version;
- operator/shape/dtype;
- source revision;
- before/after latency;
- profiler evidence;
- optimization change;
- KEEP/REVERT decision.

Never promote “double buffer is faster” as a universal rule.

# Cross-generation quarantine

Any finding sourced only from A2/A3 CCE Intrinsic docs, another DaVinci generation, external repo or model memory belongs in `quarantine` until current Ascend 310 evidence confirms it.

# Output

Create/update Markdown cards under `knowledge/` using the templates and update `knowledge/index.md`.
