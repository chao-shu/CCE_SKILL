# Package Manifest

Version: **2.0.0**
Target: **original Ascend 310 / DaVinci / CCE-C**

Files: **57**

## Contents

- `.gitignore` — 95 bytes — `d958b5f89a5bf3a1…`
- `.opencode/skills/ascend310-ccec-accuracy-validation/SKILL.md` — 1797 bytes — `6481c0775346e4a9…`
- `.opencode/skills/ascend310-ccec-baseline-codegen/SKILL.md` — 2856 bytes — `e13d4180e89759fb…`
- `.opencode/skills/ascend310-ccec-build-debug/SKILL.md` — 1611 bytes — `3253a7cb39bb4acb…`
- `.opencode/skills/ascend310-ccec-davinci-design/SKILL.md` — 4965 bytes — `7a9ee406ce573076…`
- `.opencode/skills/ascend310-ccec-environment/SKILL.md` — 2457 bytes — `c9416238f4d69167…`
- `.opencode/skills/ascend310-ccec-kb-curation/SKILL.md` — 1667 bytes — `d98ff53a5f355647…`
- `.opencode/skills/ascend310-ccec-kb-retrieval/SKILL.md` — 1983 bytes — `0ee855fec1a81e26…`
- `.opencode/skills/ascend310-ccec-operator-orchestrator/SKILL.md` — 7593 bytes — `ff6e79cdfa47955e…`
- `.opencode/skills/ascend310-ccec-performance-optimization/SKILL.md` — 2196 bytes — `8d426c2e87deeb11…`
- `.opencode/skills/ascend310-ccec-profiling/SKILL.md` — 1413 bytes — `151171cca8db7075…`
- `.opencode/skills/ascend310-ccec-regression/SKILL.md` — 898 bytes — `f8011ea4d1dbc805…`
- `.opencode/skills/ascend310-ccec-release-audit/SKILL.md` — 1151 bytes — `fd0f971dc8093990…`
- `.opencode/skills/ascend310-ccec-repo-context/SKILL.md` — 1581 bytes — `f5c9e6bce3a7adef…`
- `.opencode/skills/ascend310-ccec-semantic-analysis/SKILL.md` — 1255 bytes — `e049339d7e63a622…`
- `.opencode/skills/ascend310-ccec-test-generation/SKILL.md` — 1244 bytes — `2c8950683a276fe1…`
- `.operator-agent/runs/.gitkeep` — 0 bytes — `e3b0c44298fc1c14…`
- `AGENTS.md` — 2195 bytes — `773e49fe1b318229…`
- `PROMPT_EXAMPLES.md` — 1469 bytes — `7d22b34485d343a7…`
- `README.md` — 6201 bytes — `d264565c068081b8…`
- `SOURCES.md` — 2036 bytes — `5abf071e10cbd05b…`
- `WORKFLOW_MAP.md` — 2121 bytes — `506446b29fa44c4e…`
- `contracts/DESIGN_SPEC.md` — 1009 bytes — `de5f07f954b09332…`
- `contracts/KB_EVIDENCE.md` — 636 bytes — `067e3ed10f5faea6…`
- `contracts/RELEASE_REPORT.md` — 554 bytes — `71da92d11c6581b9…`
- `contracts/RUN_STATE.md` — 432 bytes — `9ac3ba955feb0523…`
- `contracts/SEMANTIC_SPEC.md` — 805 bytes — `ff16eaa509d2bca6…`
- `contracts/STAGE_REPORT.md` — 453 bytes — `5da3e2b76ab78f3a…`
- `contracts/TEST_PLAN.md` — 777 bytes — `0f84df585e0d4c5c…`
- `knowledge/README.md` — 1169 bytes — `74480f8ea813586b…`
- `knowledge/_templates/api-card.md` — 528 bytes — `4b87efca3b145e35…`
- `knowledge/_templates/failure-case.md` — 344 bytes — `687089e1c4245b5e…`
- `knowledge/_templates/golden-operator.md` — 410 bytes — `4a23825ac885f617…`
- `knowledge/_templates/official-reference.md` — 277 bytes — `bc3b21b201282bf9…`
- `knowledge/_templates/operator-pattern.md` — 353 bytes — `0c8c59ddac72503d…`
- `knowledge/_templates/performance-case.md` — 399 bytes — `c0fb2f0b2f68592e…`
- `knowledge/_templates/project-convention.md` — 216 bytes — `4d3f6f0edc434cac…`
- `knowledge/api/README.md` — 108 bytes — `c7dda69be43e5b69…`
- `knowledge/failures/cross-generation-ccec-contamination.md` — 928 bytes — `68830e3c033cbb93…`
- `knowledge/golden-operators/README.md` — 91 bytes — `883de0ce86b8eb60…`
- `knowledge/hardware/ascend310/README.md` — 524 bytes — `b98266bbc98365d7…`
- `knowledge/index.md` — 75 bytes — `51141cf62247863a…`
- `knowledge/local-docs/README.md` — 453 bytes — `50614fefba964951…`
- `knowledge/official/README.md` — 124 bytes — `aa8d2646a52dcfdd…`
- `knowledge/official/ccec-davinci-bootstrap.md` — 1397 bytes — `b3b7c808182c43a9…`
- `knowledge/patterns/vector-gm-ub-baseline.md` — 1289 bytes — `efa83a02738c0263…`
- `knowledge/performance/README.md` — 114 bytes — `5e285ecfaffc83fe…`
- `knowledge/project/README.md` — 122 bytes — `d6941407abb15dd7…`
- `knowledge/project/target-contract.md` — 755 bytes — `21012a5b63ab38b0…`
- `knowledge/quarantine/README.md` — 166 bytes — `2ce28688897b1c32…`
- `tools/discover_ccec.py` — 1099 bytes — `8ce5dc6048eaa4dd…`
- `tools/init_run.py` — 922 bytes — `2ab871fbd9e8b6d3…`
- `tools/kb_index.py` — 4345 bytes — `592f106b066fa4d5…`
- `tools/kb_lint.py` — 2287 bytes — `06dc1cc530a7799e…`
- `tools/kb_query.py` — 3970 bytes — `782006a39dd354a7…`
- `tools/self_check.py` — 1234 bytes — `9eb097b02f67b6cc…`
- `tools/validate_stage_report.py` — 438 bytes — `a57ff1472366ff44…`
