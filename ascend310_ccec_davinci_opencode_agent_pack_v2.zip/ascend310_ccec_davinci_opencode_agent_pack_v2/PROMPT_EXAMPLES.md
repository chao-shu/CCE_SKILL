# Prompt Examples

## Develop from Python

```text
以 subagent 的方式使用 skill `ascend310-ccec-operator-orchestrator`。
参考实现：python_ref/foo.py。
目标固定为原始 Ascend 310 NPU、达芬奇架构、CCE-C 算子语言。
禁止为了方便改成 Ascend C / TIK / TBE。
完整执行 semantic → KB → DaVinci design → CCE-C codegen → build → accuracy → profile → optimize → regression → release。
```

## Repair an existing CCE-C kernel

```text
以 subagent 的方式使用 skill `ascend310-ccec-operator-orchestrator`。
Python oracle 是 python_ref/foo.py；现有实现位于 src/foo.cce。
优先保留当前工程的 CCE-C 编译/注册方式。定位最早的根因，不要大面积重写。
```

## Only design the kernel

```text
以 subagent 的方式使用 skill `ascend310-ccec-davinci-design`。
读取 semantic_spec.json、environment.json、repo_context.json、kb_evidence.json。
只做 Ascend 310 / DaVinci / CCE-C 的内存层级、AI Core、多核、DMA、Vector/Cube、pipeline/event、UB offset 和 tail 设计，不写正式代码。
```

## Optimize

```text
以 subagent 的方式使用 skill `ascend310-ccec-performance-optimization`。
只优化已经 BUILD=PASS 且 ACCURACY=PASS 的 CCE-C kernel。
根据真实 profile 逐个验证 DMA 粒度、double buffer、pipeline overlap、event placement、vector repeat/mask/stride、UB reuse、多核切分等候选项；每轮必须 KEEP 或 REVERT。
```
