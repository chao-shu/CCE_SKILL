---
id: PROJECT-TARGET-ASCEND310-CCEC
kind: project
title: "Project target contract: original Ascend 310 + DaVinci + CCE-C"
status: VERIFIED
soc: ["Ascend310"]
architecture: ["DaVinci"]
cann: ["UNKNOWN"]
backend: ["cce-c"]
trust: T1
source: "project pack target contract"
tags: ["target", "backend", "davinci"]
---

# Convention

This workflow targets original Ascend 310 hardware and direct CCE-C `.cce` operator development. Ascend 310P and Ascend C are not default substitutes.

# Runtime requirement

The environment stage must still verify the actual detected SoC, compiler and repository conventions. If repository evidence contradicts the target contract, the orchestrator must surface the contradiction rather than silently migrating the backend.
