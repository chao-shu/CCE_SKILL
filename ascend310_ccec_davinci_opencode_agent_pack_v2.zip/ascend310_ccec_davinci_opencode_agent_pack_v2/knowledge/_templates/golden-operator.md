---
id: GOLDEN-CCEC-REPLACE-ME
kind: golden
status: PROVISIONAL
soc: ["Ascend310"]
architecture: ["DaVinci"]
cann: ["UNKNOWN"]
compiler: ["UNKNOWN"]
backend: ["cce-c"]
op_family: []
dtype: []
trust: T3
build: NOT_RUN
accuracy: NOT_RUN
board: NOT_RUN
source_run: ""
source_paths: []
---

# Semantic contract

# DaVinci design

# Intrinsics used

# Memory/event/tail strategy

# Verification

# Reuse boundaries
