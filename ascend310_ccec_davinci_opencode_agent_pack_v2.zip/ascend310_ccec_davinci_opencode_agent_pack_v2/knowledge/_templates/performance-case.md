---
id: PERF-CCEC-REPLACE-ME
kind: performance
status: PROVISIONAL
soc: ["Ascend310"]
architecture: ["DaVinci"]
cann: ["UNKNOWN"]
compiler: ["UNKNOWN"]
backend: ["cce-c"]
op_family: []
dtype: []
shape: []
trust: T3
source_run: ""
decision: "KEEP|REVERT"
---

# Baseline

# Profiler bottleneck

# Single hypothesis

# Change

# Accuracy result

# Before/after measurement

# Decision and limitations
