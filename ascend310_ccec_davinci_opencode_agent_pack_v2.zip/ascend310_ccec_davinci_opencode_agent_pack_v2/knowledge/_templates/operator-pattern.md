---
id: PATTERN-CCEC-REPLACE-ME
kind: pattern
status: PROVISIONAL
soc: ["Ascend310"]
architecture: ["DaVinci"]
cann: ["UNKNOWN"]
backend: ["cce-c"]
op_family: []
dtype: []
trust: T6
source_goldens: []
---

# Applicability

# Core partition

# GM/UB/L1/L0 plan

# DMA plan

# Vector/Cube plan

# Pipeline/event plan

# Tail plan

# Known counterexamples
