---
id: PROJECT-CCEC-REPLACE-ME
kind: project
status: VERIFIED
soc: ["Ascend310"]
architecture: ["DaVinci"]
cann: ["UNKNOWN"]
backend: ["cce-c"]
trust: T1
source: ""
---

# Convention

# Evidence

# Files / commands
