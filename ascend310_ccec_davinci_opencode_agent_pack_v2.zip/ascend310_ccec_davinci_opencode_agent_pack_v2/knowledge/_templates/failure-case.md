---
id: FAIL-CCEC-REPLACE-ME
kind: failure
status: PROVISIONAL
soc: ["Ascend310"]
architecture: ["DaVinci"]
cann: ["UNKNOWN"]
compiler: ["UNKNOWN"]
backend: ["cce-c"]
trust: T6
failure_class: UNKNOWN
error_signature: []
verified_fix: false
source_run: ""
---

# Symptom

# Root cause

# Bad pattern

# Verified fix

# Scope / non-applicability
