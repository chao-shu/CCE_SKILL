# Quarantine

Place A2/A3-only docs, cross-generation examples, external snippets and unverified model hypotheses here until current Ascend 310 evidence proves them.
