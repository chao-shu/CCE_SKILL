---
id: OFFICIAL-CCEC-DAVINCI-BOOTSTRAP
kind: official
title: "CCE-C and DaVinci public-reference bootstrap"
status: PROVISIONAL
soc: ["Ascend310", "OTHER"]
architecture: ["DaVinci"]
cann: ["MULTIPLE"]
backend: ["cce-c"]
trust: T5
compatibility: CONCEPT_ONLY
usable_for_codegen: false
source: "Huawei Ascend/MindSpore public documentation; see SOURCES.md"
tags: ["cce-c", "davinci", "intrinsic", "bootstrap"]
---

# Established concepts

Public Huawei/MindSpore material defines CCE-C as C code produced/developed by CCE and DaVinci as Huawei's AI chip architecture. Public TIK documentation describes TIK as a higher-level DSL that lowers into CCE-C before CCE compilation.

Public CCE Intrinsic examples demonstrate the low-level programming categories relevant to this workflow: explicit GM/UB address spaces, direct data-movement/vector intrinsics and explicit pipeline synchronization.

# Compatibility limit

This card is intentionally `CONCEPT_ONLY` and `usable_for_codegen: false` because recent public CCE Intrinsic product support matrices focus on newer A2/A3 devices. It cannot establish that a specific intrinsic/signature is legal on the user's original Ascend 310 environment.

# Required promotion evidence

Create separate exact-version API cards backed by the local Ascend 310 CCE compiler/repository or exact-compatible official documentation before production code generation.
