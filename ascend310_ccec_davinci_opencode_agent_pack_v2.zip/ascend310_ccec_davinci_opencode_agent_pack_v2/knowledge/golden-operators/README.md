# Golden Operators

Golden requires clean build + accuracy + actual Ascend 310 board PASS.
