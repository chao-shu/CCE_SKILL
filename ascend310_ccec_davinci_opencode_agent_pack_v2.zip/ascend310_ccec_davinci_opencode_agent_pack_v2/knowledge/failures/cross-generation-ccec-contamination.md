---
id: FAIL-CCEC-CROSS-GENERATION-CONTAMINATION
kind: failure
title: "Cross-generation CCE Intrinsic contamination"
status: PROVISIONAL
soc: ["Ascend310"]
architecture: ["DaVinci"]
cann: ["UNKNOWN"]
backend: ["cce-c"]
trust: T5
failure_class: CCE_INTRINSIC_NOT_AVAILABLE
verified_fix: false
source: "public CCE Intrinsic support matrices + architecture policy"
tags: ["compatibility", "intrinsic", "a2", "a3", "ascend310"]
---

# Symptom

An Agent copies a CCE Intrinsic signature or hardware rule from newer A2/A3 documentation into an original Ascend 310 `.cce` kernel.

# Risk

The intrinsic may be unavailable, have a different signature/constraint, or encode a hardware feature not present on the original 310 generation.

# Prevention

Require current compiler/repository or exact-compatible Ascend 310 evidence before code generation. Treat newer public CCE Intrinsic documentation as concept-only until proven locally.
