# Ascend 310 / CCE-C / DaVinci OpenCode Operator Agent Pack

Version: **2.0.0**  
Target: **Ascend 310 NPU (original 310, not 310P)**  
Kernel language: **CCE-C / CCE Intrinsic-style `.cce` programming**  
Architecture: **DaVinci AI Core**

This package is a Markdown-first, evidence-gated workflow for converting Python reference implementations into correct, buildable and optimized CCE-C kernels for Ascend 310.

## Important correction from V1

This package does **not** use Ascend C (`AscendC::`, `TPipe`, `TQue`) as the primary programming model and does **not** treat Ascend 310P as the target.

The primary backend is low-level CCE-C / CCE compiler programming. The workflow expects architecture-facing concepts such as:

- `.cce` device source;
- `__global__`, `__aicore__` kernel entry conventions when supported by the installed toolchain;
- explicit address spaces such as GM / UB / L1/L0 only when verified for the installed compiler;
- direct CCE intrinsic use;
- explicit MTE / Vector / Cube pipeline dependencies;
- manual `set_flag` / `wait_flag` / barrier reasoning when required;
- vector masks, repeat counts and stride semantics;
- explicit UB offset/lifetime planning;
- DaVinci AI Core multicore partitioning via the repository/toolchain's verified block-index mechanism;
- explicit DMA/alignment/tail handling.

The agent must never substitute modern Ascend C APIs for CCE-C merely because the mathematical operator is similar.

## Architecture

The package intentionally uses **one master workflow Skill plus specialized stage Skills**. No `.opencode/agents/*.md` layer is required.

The controlling Skill explicitly tells the parent Agent to use a fresh subagent by name, for example:

```text
以 subagent 的方式使用 skill `ascend310-ccec-davinci-design`，只读取指定 artifact，完成 DaVinci/CCE-C 硬件映射，并返回 stage report。
```

This matches an OpenCode setup where explicitly naming a Skill in a subagent invocation is sufficient to launch the corresponding subagent + Skill.

## Included Skills

1. `ascend310-ccec-operator-orchestrator`
2. `ascend310-ccec-environment`
3. `ascend310-ccec-repo-context`
4. `ascend310-ccec-semantic-analysis`
5. `ascend310-ccec-kb-retrieval`
6. `ascend310-ccec-test-generation`
7. `ascend310-ccec-davinci-design`
8. `ascend310-ccec-baseline-codegen`
9. `ascend310-ccec-build-debug`
10. `ascend310-ccec-accuracy-validation`
11. `ascend310-ccec-profiling`
12. `ascend310-ccec-performance-optimization`
13. `ascend310-ccec-regression`
14. `ascend310-ccec-release-audit`
15. `ascend310-ccec-kb-curation`

## First use

Copy this package into the root of your operator repository, then invoke:

```text
以 subagent 的方式使用 skill `ascend310-ccec-operator-orchestrator`。
Python 参考实现是 python_ref/my_op.py。
目标为 Ascend 310，达芬奇架构，必须生成/修改 CCE-C 算子，不要改写成 Ascend C/TIK/TBE。
按完整流程执行到 release audit；所有 API、intrinsic、地址空间、pipeline、mask、stride、DMA 约束必须以当前工程、本机 CCE 编译器或与当前 CANN/310 匹配的证据为准。
```

## Runtime artifacts

Every run is isolated under:

```text
.operator-agent/runs/<run_id>/
```

Expected artifacts include:

```text
environment.json
repo_context.json
semantic_spec.json
kb_evidence.json
test_plan.json
design.json
design.md
code_report.json
build_report.json
accuracy_report.json
profile_report.json
optimization_log.jsonl
regression_report.json
release_report.json
```

## Knowledge base

`knowledge/` is deliberately provenance-aware. The most dangerous error in this domain is importing an intrinsic or hardware rule from the wrong SoC/CANN generation.

Trust order is therefore biased toward **your real Ascend 310 environment**:

- `T0` — current local CCE compiler acceptance / disassembly / actual current build evidence;
- `T1` — current repository's Ascend 310 CCE-C code that clean-builds and runs;
- `T2` — official documentation matching the installed CANN/CCE version and Ascend 310;
- `T3` — local board-verified Golden Operator on Ascend 310;
- `T4` — same-generation official CCE-C/TIK-generated CCE-C material with compatibility evidence;
- `T5` — documentation/examples from another SoC generation (including A2/A3 CCE Intrinsic): concept-only until locally proven;
- `T6` — external examples or model memory: search clue only.

**T5/T6 may never establish CCE-C API legality for Ascend 310.**

## Knowledge-base utilities

Standard-library-only helpers are included:

```bash
python tools/init_run.py --operator MyOp
python tools/kb_lint.py
python tools/kb_index.py
python tools/kb_query.py "copy gm ub vector tail" --soc Ascend310 --backend cce-c
python tools/discover_ccec.py
python tools/validate_stage_report.py .operator-agent/runs/<run_id>/build_report.json
```

## Core engineering rules

1. Python is the semantic oracle, not a line-by-line CCE-C template.
2. CCE-C is the required backend unless the user explicitly changes the requirement.
3. Never replace CCE-C with Ascend C / TIK / TBE for convenience.
4. Never invent an intrinsic, overload, mask rule, repeat rule, stride unit, DMA granularity, memory limit or pipeline behavior.
5. Current A2/A3 CCE Intrinsic documents are **not** proof of compatibility with original Ascend 310.
6. Explicitly reason about GM/UB/L1/L0 memory movement as applicable.
7. Explicitly prove pipeline ordering and event reuse safety.
8. Explicitly handle core remainder, tile remainder, vector-mask remainder and DMA tail safety.
9. Build PASS is required before numerical verification.
10. Accuracy PASS is required before optimization.
11. Optimization requires measured KEEP/REVERT evidence.
12. `NOT_RUN` is never `PASS`.
13. Only verified experience is promoted into the trusted KB.

## Why the KB is critical

Direct CCE-C is low-level architecture-defined programming. A semantically similar kernel from a newer DaVinci generation can compile differently or use different intrinsic signatures and constraints. Therefore this pack treats your existing working Ascend 310 `.cce` sources and installed compiler behavior as first-class knowledge, not merely examples.
