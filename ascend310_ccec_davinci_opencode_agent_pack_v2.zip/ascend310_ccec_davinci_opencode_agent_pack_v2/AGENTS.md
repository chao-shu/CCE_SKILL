# Ascend 310 CCE-C / DaVinci Operator Rules

For operator creation, porting, repair, verification or optimization targeting this repository, load `ascend310-ccec-operator-orchestrator` as the controlling workflow.

## Target invariant

Unless the user explicitly overrides it:

- hardware: **Ascend 310** (not 310P);
- architecture: **DaVinci AI Core**;
- kernel programming model: **CCE-C / CCE compiler intrinsic-style `.cce` code**;
- Python source: semantic reference only.

## Mandatory subagent convention

When the orchestrator delegates a stage, use a **fresh subagent** and explicitly say:

```text
以 subagent 的方式使用 skill `<skill-name>` ...
```

The subagent must load that Skill and receive only the required artifacts/files. Do not create or depend on `.opencode/agents/*.md` role files.

## Permanent invariants

1. Never silently change the backend to Ascend C, TIK or TBE.
2. Detect the installed CANN/CCE/BiSheng toolchain and exact repository build flow; never guess them.
3. Prefer current-repository and current-compiler evidence over web examples.
4. Never use A2/A3 CCE Intrinsic documentation as proof of an intrinsic's legality on original Ascend 310.
5. Never invent CCE-C intrinsic names, signatures, address-space keywords, repeat semantics, stride units, masks, event IDs or pipeline constraints.
6. For every DMA/vector/cube instruction, reason about address space, byte/element units, alignment, valid range and synchronization.
7. Explicitly plan UB/L1/L0 memory offsets and prove non-overlapping live ranges.
8. Explicitly handle multicore tails, tiling tails, vector-mask tails and DMA tails.
9. Avoid unsafe GM overread/overwrite merely to satisfy an aligned transfer.
10. Build before accuracy; accuracy before profiling; profile before optimization.
11. Never weaken tolerance to force accuracy PASS.
12. Every performance change must have KEEP/REVERT evidence.
13. Never claim Ascend 310 board verification unless that board actually executed the kernel.
14. Preserve `PASS`, `FAIL`, `BLOCKED`, `NOT_RUN` exactly.
15. Unverified knowledge goes to `knowledge/quarantine/`.

## Runtime artifact root

Use:

```text
.operator-agent/runs/<run_id>/
```
