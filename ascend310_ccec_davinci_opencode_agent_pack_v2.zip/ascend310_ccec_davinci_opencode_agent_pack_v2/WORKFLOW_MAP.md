# Ascend 310 CCE-C Workflow Map

```text
PYTHON REFERENCE / EXISTING CCE-C
               │
               ▼
ascend310-ccec-operator-orchestrator
               │
     ┌─────────┴──────────┐
     ▼                    ▼
 environment          repo-context
 fresh subagent       fresh subagent
     └─────────┬──────────┘
               ▼
       semantic-analysis
               │
      ┌────────┴────────┐
      ▼                 ▼
 kb-retrieval      test-generation
      └────────┬────────┘
               ▼
     davinci-hardware-design
               │
               ▼
       baseline-codegen
           CCE-C only
               │
               ▼
           build-debug
       CCE/BiSheng compiler
               │ PASS
               ▼
      accuracy-validation
               │ PASS
               ▼
            profiling
               │
               ▼
  performance-optimization loop
      BUILD → ACCURACY → PROFILE
          KEEP / REVERT
               │
               ▼
           regression
               │ PASS
               ▼
         release-audit
               │
               ▼
          kb-curation
               │
               ▼
              DONE
```

## Failure routing

```text
Wrong Python semantics                → semantic-analysis
Wrong intrinsic/version assumption    → kb-retrieval
Wrong DaVinci memory/pipeline design  → davinci-design
Wrong UB offsets/liveness             → davinci-design / codegen
Wrong event/barrier ordering           → davinci-design / codegen
Vector mask/repeat/stride defect       → davinci-design / codegen
DMA alignment/tail defect              → davinci-design / codegen
CCE compile error                      → build-debug
Numerical mismatch                     → classified upstream owner
Performance candidate regression       → REVERT
Final regression failure               → owning upstream stage
```
