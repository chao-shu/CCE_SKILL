# Knowledge overlap decisions

Both initial ingestion and routine curation use this contract. It does not change their independent invocation boundaries.

Before promotion run:

```bash
python tools/kb_dedupe.py --knowledge RUN_DIR/kb_candidates --against knowledge
```

For curation replace `kb_candidates` with `kb_curation_candidates`. Save the JSON output as run evidence. The tool compares candidates internally and against the existing KB; it never writes/deletes cards. Exit code 1 means exact duplicate facts need resolution; exit code 0 may still contain overlap hints requiring review.

Review every candidate, including ones without a hint. The detector finds identical body/scope and overlaps through ID, symbol, title, operator family or failure signature; it does not prove semantic equivalence or detect every paraphrase.

| Decision | When | Action |
|---|---|---|
| SKIP | Existing card already contains the same fact and equally strong evidence; or no reusable fact | Keep canonical card, record reason; do not create another ID |
| MERGE | Same target/signature/constraint scope, with useful new corroboration or a verified correction | Update the existing ID, preserving source evidence and compatibility limits |
| ADD | New reusable fact or materially distinct overload/version/shape scope | New ID, record why separate reuse is necessary; cross-link related cards |
| QUARANTINE | Contradictory or insufficient evidence | Preserve both claims in the report; candidate gets QUARANTINED and usable_for_codegen=false |

Do not union version/dtype scopes when only one pairing is verified. A same-named API in different compiler generations may require separate cards. Never overwrite stronger evidence based on recency alone. Prefer a canonical card plus additional evidence over a new card for every operator run. DEPRECATED/QUARANTINED cards are preserved for audit and excluded from active duplicate blocking; do not mislabel useful cards merely to bypass lint.

Every candidate must have an entry in `dedup_decisions` in the ingestion/curation report containing `candidate_id`, `decision`, `existing_ids`, `reason`, `scope_difference`, and `evidence_added`. MERGE candidates reuse the canonical ID. Keep discarded raw candidates in run storage, but assemble only the final intended writes in `RUN_DIR/kb_promotion/` (ingestion) or `RUN_DIR/kb_curation_promotion/` (curation) before candidate lint/index checks. This prevents raw duplicate candidates from blocking otherwise valid resolved writes.

Run lint on the final complete KB. It rejects duplicate IDs and identical non-empty body plus compatibility scope even when IDs differ. Overlap hints must be explained by the decisions; they are not grounds for automatic deletion. No-op curation is a valid PASS with a report explaining SKIP; it need not produce a new card.
