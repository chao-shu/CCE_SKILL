# Stage Report Contract

Every delegated stage must write exactly one machine-readable report to:

```text
RUN_DIR/stage_reports/<stage>.json
```

The primary artifact and the stage report are separate files. Primary artifacts such as `semantic_spec.json` do not need to duplicate this envelope. Canonical stage names use lowercase snake case, for example `repo_context`, `kb_retrieval`, `davinci_design`, `baseline_codegen`, `release_audit`, `kb_curation`, and `kb_ingestion`.

Every stage report must contain at least:

```json
{
  "run_id": "",
  "stage": "",
  "status": "PASS|FAIL|BLOCKED|NOT_RUN",
  "inputs": [],
  "input_hashes": {},
  "outputs": [],
  "evidence": [],
  "assumptions": [],
  "warnings": [],
  "blockers": [],
  "failure_class": null,
  "recommended_next_stage": null
}
```

Rules:

- `PASS` requires at least one evidence item and at least one output, with no blockers or failure class.
- `FAIL` requires a failure class and failure evidence.
- `BLOCKED` requires at least one concrete blocker.
- `NOT_RUN` can never be interpreted as `PASS`.
- `outputs` lists the primary artifacts or source changes produced by the stage.
- Non-empty `inputs` require recorded `input_hashes` so downstream invalidation can be evidence-based.

The orchestrator must validate every report with:

```bash
python tools/validate_stage_report.py RUN_DIR/stage_reports/<stage>.json --expected-stage <stage>
```

An invalid report fails the stage gate even if the subagent's prose claims success.
