# Stage Report Contract

Every delegated stage must write exactly one machine-readable report to:

```text
RUN_DIR/stage_reports/<stage>.json
```

The primary artifact and the stage report are separate files. Primary artifacts such as `semantic_spec.json` do not need to duplicate this envelope. Canonical stage names use lowercase snake case, for example `repo_context`, `kb_retrieval`, `davinci_design`, `baseline_codegen`, `release_audit`, `kb_curation`, and `kb_ingestion`.

Every stage report must contain at least:

```json
{
  "run_id": "",
  "stage": "",
  "status": "PASS|FAIL|BLOCKED|NOT_RUN",
  "inputs": [],
  "input_hashes": {},
  "outputs": [],
  "output_hashes": {},
  "evidence": [],
  "assumptions": [],
  "warnings": [],
  "blockers": [],
  "failure_class": null,
  "recommended_next_stage": null
}
```

Rules:

- `PASS` requires at least one evidence item and at least one output, with no blockers or failure class.
- `FAIL` requires a failure class and failure evidence.
- `BLOCKED` requires at least one concrete blocker.
- `NOT_RUN` can never be interpreted as `PASS`.
- `outputs` lists the primary artifacts or source changes produced by the stage.
- `inputs` and `outputs` are arrays of regular file paths. Relative paths are resolved against the project working directory (or explicit `--root`), not against the report directory.
- `input_hashes` and `output_hashes` must have exactly the corresponding path keys; each value is the real 64-digit SHA-256, optionally prefixed by `sha256:`. Every referenced file must exist and match its hash.
- `evidence` contains objects such as `{"path":"logs/build.log","sha256":"<64-digit SHA-256>","description":"command, exit code and compiler diagnostics"}`. A free-text claim, URL or evidence ID alone cannot satisfy this gate. Capture relevant external evidence in a local ledger with URL/version/location; reference and hash that ledger. The validator verifies file integrity, not the truth of prose inside the file; the orchestrator/release auditor must still assess it.
- Record all consumed sources, build configuration, test harness, design and prior reports needed to bind the result to the implementation. Directories must be represented by an inventory listing relevant file hashes.
- If a stage modifies an input, save its pre-change bytes in `RUN_DIR/input_snapshots/<stage>/` and reference that immutable snapshot as input; reference the final modified file and hash as output. Preserve the original-path mapping in the primary artifact. Never hash pre-change bytes under the live post-change filename.
- Do not include the stage report itself, mutable `state.json`, or an actively appended log among its hashed files. Freeze a log copy first. For a missing required input, report a blocker rather than listing a non-existent file as consumed evidence.
- `RUN_DIR/state.json` must exist, and its `run_id`, the report's `run_id`, and the RUN_DIR basename must match. Independent workflows also initialize their run with `tools/init_run.py`.

The orchestrator must validate every report with:

```bash
python tools/validate_stage_report.py RUN_DIR/stage_reports/<stage>.json --expected-stage <stage>
```

An invalid report fails the stage gate even if the subagent's prose claims success.

Revalidate immediately before consuming a gate, not only once after the producer finishes. A source/hash mismatch invalidates the result and its dependent stages. Old 3.1.0 reports require regeneration from retained real evidence; do not manufacture missing hashes.
