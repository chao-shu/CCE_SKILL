# Test Plan Contract

`test_plan.json` must cover semantic and hardware-boundary cases.

Case classes should include applicable:

- minimum shape;
- one vector-mask unit minus/at/plus boundary;
- one DMA transfer unit minus/at/plus boundary when safe/testable;
- one tile minus/at/plus boundary;
- one-core and multicore remainder boundaries;
- UB-capacity-near cases only when the exact capacity/plan is verified;
- representative production shapes;
- zeros/ones/negative/mixed signs/extreme magnitudes;
- NaN/Inf/domain boundaries where semantically relevant;
- dtype variants.

The test generator may not invent a hardware boundary value. If the exact value is unknown, it must reference a design/environment variable and let later stages instantiate it after verification.
