# KB Evidence Contract

`kb_evidence.json` must preserve provenance and compatibility.

Each selected evidence item should include:

```json
{
  "id": "",
  "kind": "api|golden|pattern|failure|performance|official|project",
  "status": "PROVISIONAL|VERIFIED|QUARANTINED|DEPRECATED",
  "trust": "T0|T1|T2|T3|T4|T5|T6",
  "soc": ["Ascend310P"],
  "architecture": ["DaVinci"],
  "cann": [],
  "compiler": [],
  "backend": ["cce-c"],
  "source": "",
  "verification": [],
  "compatibility": "EXACT|PROVEN_COMPATIBLE|CONCEPT_ONLY|UNKNOWN",
  "usable_for_codegen": false,
  "notes": ""
}
```

Only evidence explicitly marked `usable_for_codegen=true` may establish an intrinsic/signature/constraint for production code. Such an item must also be `VERIFIED`, use trust `T0`-`T4`, match `Ascend310P` and `cce-c`, identify concrete CANN/compiler versions, have `EXACT` or `PROVEN_COMPATIBLE` compatibility, and contain verification evidence IDs.

Conceptual retrieval using `ANY`, `UNKNOWN`, `CONCEPT_ONLY`, T5 or T6 evidence must remain separate and may only guide further verification.
