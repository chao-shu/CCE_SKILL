# Release Report Contract

Final report must state:

```json
{
  "target": "Ascend310P",
  "architecture": "DaVinci",
  "backend": "CCE-C",
  "SEMANTICS": "PASS|FAIL|BLOCKED|NOT_RUN",
  "DESIGN": "PASS|FAIL|BLOCKED|NOT_RUN",
  "BUILD": "PASS|FAIL|BLOCKED|NOT_RUN",
  "ACCURACY": "PASS|FAIL|BLOCKED|NOT_RUN",
  "BOARD": "PASS|FAIL|BLOCKED|NOT_RUN",
  "PERFORMANCE": "PASS|FAIL|BLOCKED|NOT_RUN",
  "REGRESSION": "PASS|FAIL|BLOCKED|NOT_RUN",
  "FINAL": "PASS|FAIL|BLOCKED"
}
```

`BOARD=NOT_RUN` forbids claims such as “verified on Ascend 310P hardware”.

For terminal closeout after an unrecoverable upstream `FAIL` or `BLOCKED`, record the real upstream status, mark prohibited/unexecuted downstream stages `NOT_RUN`, and set `FINAL` to `FAIL` or `BLOCKED`. This report closes the run for audit and curation; it is not release approval.
