# Optimization revision and evidence contract

Use immutable per-iteration records under `RUN_DIR/optimization/<iteration>/`. Keep baseline and failed candidates; never overwrite their logs with a later run. `optimization_log.jsonl` records the accepted checkpoint and candidate checkpoint paths, source hashes, design identifier, build/accuracy/profile report paths and hashes, and KEEP/REVERT reason.

Before modifying an accepted revision:

1. Revalidate its build/accuracy/profiling stage reports against the current files and run ID. A baseline profile filename alone is not evidence; all three gates must be PASS and reference the accepted revision.
2. Prepare `paths.json`, an explicit list of project-relative files the experiment may affect. Include kernel/host/build/test sources, `design.json`, `design.md`, `code_report.json`, build/accuracy/profile primary reports and their stage reports, and local logs/binaries these reports hash. Include planned new filenames even if absent. Include an existing final regression report if one is invalidated. Never include unrelated user files, `.git`, mutable run state, append-only optimization logs or the checkpoint directory.
3. Save the accepted checkpoint before edits. If new affected paths are discovered, revert the current attempt first, extend the path list and take a fresh checkpoint before restarting.

```bash
python tools/optimization_checkpoint.py save --paths RUN_DIR/optimization/001/paths.json --snapshot RUN_DIR/optimization/001/accepted
```

For each candidate, update its design and source coherently, then run BUILD → ACCURACY → PROFILE. The controller delegates these verification stages to fresh corresponding stage subagents; the optimizer proposes changes and does not self-certify its own numerical/performance claims. Copy final candidate reports/logs to this iteration before the next attempt. The controller owns state transitions and invalidates dependent gates.

For REVERT:

1. Save the candidate using the same path list under a separate `candidate` checkpoint, and preserve its diagnostics/decision. This also preserves any new file that rollback will remove.
2. Restore the accepted checkpoint:

```bash
python tools/optimization_checkpoint.py restore --snapshot RUN_DIR/optimization/001/accepted
python tools/optimization_checkpoint.py check --snapshot RUN_DIR/optimization/001/accepted
```

3. Revalidate restored build/accuracy/profile reports against the restored files. If a binary/log was not checkpointed or the toolchain/device configuration changed, rerun the affected verification; never simply relabel a failed candidate report PASS.
4. Restore the controller's accepted-revision pointer and gate statuses only after validation. Unrelated downstream results remain invalidated until rerun. Do not restore all of `state.json` blindly.

For KEEP, require all three candidate gates to pass plus a meaningful measured improvement without unacceptable shape regressions. Save a new accepted checkpoint using the complete affected-file list. End the loop on that exact source/design revision and run final independent regression. State/report writing must not race with checkpoint/restore; serialize each attempt. Apply a user-specified budget or an explicitly recorded finite iteration budget, and stop when no evidence-backed hypothesis remains.

The helper verifies all recorded snapshot hashes before mutation, restores only the listed files and modes, and removes only listed files recorded as originally absent. It is not a whole-directory rollback and does not track unlisted changes. If an I/O failure interrupts restoration, mark the run BLOCKED, retain the checkpoints, and retry recovery before starting any further optimization. A checkpoint cannot restore external device state.
