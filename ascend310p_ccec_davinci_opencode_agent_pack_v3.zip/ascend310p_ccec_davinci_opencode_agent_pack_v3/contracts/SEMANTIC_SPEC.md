# Semantic Specification Contract

`semantic_spec.json` describes **what** the Python reference computes, independent of CCE-C implementation.

Minimum fields:

```json
{
  "operator": "",
  "reference_files": [],
  "inputs": [],
  "outputs": [],
  "shape_rules": [],
  "dtype_rules": [],
  "layout_rules": [],
  "broadcast_rules": [],
  "reduction_rules": [],
  "indexing_rules": [],
  "computation": [],
  "numerical_contract": {
    "intermediate_dtypes": [],
    "accumulation_dtype": null,
    "rounding": null,
    "nan_behavior": null,
    "inf_behavior": null,
    "overflow_behavior": null
  },
  "edge_cases": [],
  "unsupported_cases": [],
  "performance_shapes": []
}
```

Do not put CCE-C implementation choices, UB offsets, vector masks, DMA bursts, event IDs or core counts into this file.
