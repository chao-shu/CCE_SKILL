# Ascend 310P CCE-C Workflow Map

```text
PYTHON REFERENCE / EXISTING CCE-C
               │
               ▼
ascend310p-ccec-operator-orchestrator
               │
     ┌─────────┴──────────┐
     ▼                    ▼
 environment          repo-context
 fresh subagent       fresh subagent
     └─────────┬──────────┘
               ▼
       semantic-analysis
               │
      ┌────────┴────────┐
      ▼                 ▼
 kb-retrieval      test-generation
      └────────┬────────┘
               ▼
     davinci-hardware-design
               │
               ▼
       baseline-codegen
           CCE-C only
               │
               ▼
           build-debug
       CCE/BiSheng compiler
               │ PASS
               ▼
      accuracy-validation
               │ PASS
               ▼
            profiling
               │
               ▼
  performance-optimization loop
      BUILD → ACCURACY → PROFILE
          KEEP / REVERT
               │
               ▼
           regression
               │ PASS
               ▼
         release-audit
               │
               ▼
          kb-curation
               │
               ▼
              DONE
```

## Failure routing

```text
Wrong Python semantics                → semantic-analysis
Wrong intrinsic/version assumption    → kb-retrieval
Wrong DaVinci memory/pipeline design  → davinci-design
Wrong UB offsets/liveness             → davinci-design / codegen
Wrong event/barrier ordering           → davinci-design / codegen
Vector mask/repeat/stride defect       → davinci-design / codegen
DMA alignment/tail defect              → davinci-design / codegen
CCE compile error                      → build-debug
Numerical mismatch                     → classified upstream owner
Performance candidate regression       → REVERT
Final regression failure               → owning upstream stage
```

If evidence-backed repair is exhausted, the terminal path is:

```text
FAIL/BLOCKED
→ prohibited downstream stages = NOT_RUN
→ release-audit closeout (FINAL=FAIL|BLOCKED)
→ kb-curation (verified failure facts only)
→ DONE
```

This closeout path does not convert failure into release approval and does not invoke any bootstrap ingestion workflow.
