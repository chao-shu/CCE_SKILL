# Prompt Examples

## Independently bootstrap the knowledge base

```text
以 subagent 的方式使用 skill `ascend310p-ccec-kb-ingestion`。
这是一次独立的知识库初始化，不要调用 operator orchestrator。
RUN_DIR=.operator-agent/runs/<run_id>。
OPERATOR_DIRS=[/path/to/known-good/operator_a, /path/to/known-good/operator_b]。
PDF_DOCS=[/path/to/ccec_interface_manual.pdf]。
目标是 Ascend 310P + DaVinci + CCE-C。
按照来源、哈希、CANN/CCE版本、编译/精度/板端证据生成候选知识卡；其他产品资料进入 quarantine；先对原始候选完成去重决定，再对 `RUN_DIR/kb_promotion/` 中的最终写入内容完成 lint、候选索引和查询，再晋升并校验完整知识库。
摄取结束后冻结 kb_ingestion_report.json，后续知识更新只交给 `ascend310p-ccec-kb-curation`。
```

## Develop from Python

```text
以 subagent 的方式使用 skill `ascend310p-ccec-operator-orchestrator`。
参考实现：python_ref/foo.py。
目标固定为 Ascend 310P NPU（不是原始 Ascend 310）、达芬奇架构、CCE-C 算子语言。
禁止为了方便改成 Ascend C / TIK / TBE。
完整执行 semantic → KB → DaVinci design → CCE-C codegen → build → accuracy → profile → optimize → regression → release。
```

## Repair an existing CCE-C kernel

```text
以 subagent 的方式使用 skill `ascend310p-ccec-operator-orchestrator`。
Python oracle 是 python_ref/foo.py；现有实现位于 src/foo.cce。
优先保留当前工程的 CCE-C 编译/注册方式。定位最早的根因，不要大面积重写。
```

## Only design the kernel

```text
以 subagent 的方式使用 skill `ascend310p-ccec-davinci-design`。
读取 semantic_spec.json、environment.json、repo_context.json、kb_evidence.json。
只做 Ascend 310P / DaVinci / CCE-C 的内存层级、AI Core、多核、DMA、Vector/Cube、pipeline/event、UB offset 和 tail 设计，不写正式代码。
写入 design artifact 和 `RUN_DIR/stage_reports/davinci_design.json`，并通过 stage report 校验。
```

## Optimize

```text
以 subagent 的方式使用 skill `ascend310p-ccec-performance-optimization`。
只优化已经 BUILD=PASS 且 ACCURACY=PASS 的 CCE-C kernel。
根据真实 profile 逐个验证 DMA 粒度、double buffer、pipeline overlap、event placement、vector repeat/mask/stride、UB reuse、多核切分等候选项；每轮必须 KEEP 或 REVERT。
```
