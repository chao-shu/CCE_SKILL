#!/usr/bin/env python3
"""Find exact duplicate facts and scope-overlap candidates; never mutate cards."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from kb_index import parse_frontmatter

# Preserve all constraint/measurement metadata, including unknown future fields.
# Only identity, presentation and provenance fields may differ for an exact fact.
NON_FACT_FIELDS = {'id', 'title', 'status', 'trust', 'source', 'verification',
                   'verified_on', 'source_run', 'source_paths', 'tags',
                   'updated_at', 'created_at'}


def values(value):
    if isinstance(value, list):
        return sorted(str(x).strip() for x in value)
    return [str(value).strip()] if value not in (None, '') else []


def cards(directory):
    result = []
    for path in sorted(Path(directory).rglob('*.md')):
        if '_templates' in path.parts or path.name.lower() in {'readme.md', 'index.md'}:
            continue
        meta, body = parse_frontmatter(path.read_text(encoding='utf-8'))
        if not meta:
            continue
        normalized = '\n'.join(line.rstrip() for line in body.strip().splitlines())
        scope = {key: values(value) for key, value in meta.items() if key not in NON_FACT_FIELDS}
        payload = json.dumps([scope, normalized], ensure_ascii=False, sort_keys=True)
        result.append({'path': str(path), 'meta': meta, 'scope': scope,
                       'body': normalized, 'fingerprint': hashlib.sha256(payload.encode()).hexdigest()})
    return result


def related(a, b):
    ma, mb = a['meta'], b['meta']
    if ma.get('kind') != mb.get('kind'):
        return False
    # Version differences remain visible for conflict review, never auto-merge.
    for key in ('soc', 'backend'):
        sa, sb = set(values(ma.get(key))), set(values(mb.get(key)))
        unknown = {'UNKNOWN', 'ANY', 'OTHER', 'MULTIPLE'}
        if sa and sb and not (sa & sb or (sa | sb) & unknown):
            return False
    symbols_a, symbols_b = set(values(ma.get('symbol'))), set(values(mb.get('symbol')))
    if symbols_a & symbols_b:
        return True
    if a['body'] and a['body'] == b['body']:
        return True
    title_a, title_b = str(ma.get('title', '')).casefold(), str(mb.get('title', '')).casefold()
    if title_a and title_a == title_b:
        return True
    # Non-API cards may lack a symbol. Surface shared families/signatures as hints.
    for key in ('op_family', 'error_signature', 'source_goldens'):
        if set(values(ma.get(key))) & set(values(mb.get(key))):
            return True
    return False


def compare(a, b):
    ma, mb = a['meta'], b['meta']
    if ma.get('status') in {'DEPRECATED', 'QUARANTINED'} or mb.get('status') in {'DEPRECATED', 'QUARANTINED'}:
        return None
    if a['body'] and a['fingerprint'] == b['fingerprint']:
        reason = 'EXACT_DUPLICATE'
    elif ma.get('id') and ma.get('id') == mb.get('id'):
        reason = 'ID_MATCH_REVIEW'
    elif related(a, b):
        reason = 'SCOPE_OVERLAP_REVIEW'
    else:
        return None
    return {'candidate': a['path'], 'candidate_id': ma.get('id'),
            'existing': b['path'], 'existing_id': mb.get('id'), 'reason': reason}


def find_overlaps(current, existing=None):
    result = []
    for i, a in enumerate(current):
        for b in current[:i]:
            if item := compare(a, b):
                result.append(item)
        for b in existing or []:
            if Path(a['path']).resolve() != Path(b['path']).resolve():
                if item := compare(a, b):
                    result.append(item)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--knowledge', default='knowledge')
    parser.add_argument('--against', help='existing KB to compare candidates against')
    args = parser.parse_args()
    for directory in (args.knowledge, args.against):
        if directory and not Path(directory).is_dir():
            parser.error(f'knowledge directory not found: {directory}')
    current = cards(args.knowledge)
    overlaps = find_overlaps(current, cards(args.against) if args.against else None)
    exact = [x for x in overlaps if x['reason'] == 'EXACT_DUPLICATE']
    print(json.dumps({'ok': not exact, 'cards_checked': len(current), 'pairs': overlaps,
                      'note': 'Hints are not semantic proof. Review every candidate; no automatic merge or delete.'},
                     indent=2, ensure_ascii=False))
    return 1 if exact else 0


if __name__ == '__main__':
    raise SystemExit(main())
