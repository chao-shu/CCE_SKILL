#!/usr/bin/env python3
"""Save/check/restore an explicitly enumerated set of project files, never a whole tree."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from validate_stage_report import file_hash


def target(root, name):
    path = Path(name)
    if path.is_absolute() or '..' in path.parts or not path.parts or '.git' in path.parts:
        raise ValueError(f'not a project-relative file: {name}')
    dst = root / path
    # Reject symlink components, including broken links and external parent links.
    for part in (dst, *dst.parents):
        if part == root:
            break
        if part.is_symlink():
            raise ValueError(f'symlink not supported: {name}')
    if dst.exists() and not dst.is_file():
        raise ValueError(f'not a regular file: {name}')
    return dst


def save(root, snapshot, names):
    root, snapshot = Path(root).resolve(), Path(snapshot).resolve()
    if snapshot.exists():
        raise ValueError('checkpoint already exists; use a new immutable checkpoint')
    if not isinstance(names, list) or not names or any(not isinstance(n, str) for n in names):
        raise ValueError('paths must be a non-empty JSON array of project-relative filenames')
    paths = [target(root, name) for name in names]
    if len(set(paths)) != len(paths):
        raise ValueError('duplicate paths')
    if any(path == snapshot or snapshot in path.parents for path in paths):
        raise ValueError('cannot checkpoint the checkpoint itself')
    # Read all bytes before writing any checkpoint metadata.
    data = [(name, path.read_bytes() if path.exists() else None) for name, path in zip(names, paths)]
    snapshot.mkdir(parents=True)
    entries = []
    for i, (name, content) in enumerate(data):
        entry = {'path': name, 'exists': content is not None, 'blob': None, 'sha256': None, 'mode': None}
        if content is not None:
            blob = snapshot / f'{i}.bin'
            blob.write_bytes(content)
            entry.update(blob=blob.name, sha256=file_hash(blob), mode=(root/name).stat().st_mode & 0o777)
        entries.append(entry)
    (snapshot/'manifest.json').write_text(json.dumps({'root': str(root), 'files': entries}, indent=2)+'\n')
    return {'saved': len(entries), 'snapshot': str(snapshot)}


def load(root, snapshot):
    root, snapshot = Path(root).resolve(), Path(snapshot).resolve()
    manifest = json.loads((snapshot/'manifest.json').read_text())
    if manifest.get('root') != str(root):
        raise ValueError('checkpoint belongs to a different project root')
    ready = []
    seen = set()
    for i, entry in enumerate(manifest['files']):
        dst = target(root, entry['path'])
        if dst in seen or dst == snapshot or snapshot in dst.parents:
            raise ValueError('duplicate or self-referential checkpoint path')
        seen.add(dst)
        data = None
        if entry['exists'] is True:
            if entry['blob'] != f'{i}.bin':
                raise ValueError('invalid checkpoint blob path')
            blob = snapshot / entry['blob']
            if blob.is_symlink() or not blob.is_file() or file_hash(blob) != entry['sha256']:
                raise ValueError(f'checkpoint corrupted: {entry["path"]}')
            if not isinstance(entry['mode'], int) or not 0 <= entry['mode'] <= 0o777:
                raise ValueError('invalid file mode')
            data = blob.read_bytes()
        elif entry['exists'] is not False:
            raise ValueError('invalid exists flag')
        ready.append((dst, entry, data))
    if not ready:
        raise ValueError('empty checkpoint')
    return ready


def check(root, snapshot):
    mismatches = []
    for dst, entry, _ in load(root, snapshot):
        if entry['exists']:
            if not dst.is_file() or file_hash(dst) != entry['sha256'] or (dst.stat().st_mode & 0o777) != entry['mode']:
                mismatches.append(entry['path'])
        elif dst.exists():
            mismatches.append(entry['path'])
    return mismatches


def restore(root, snapshot):
    ready = load(root, snapshot)  # Verify every blob/path before the first mutation.
    removed = []
    for dst, entry, data in ready:
        if entry['exists']:
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_bytes(data)
            dst.chmod(entry['mode'])
        elif dst.exists():
            dst.unlink()  # Only a recorded, originally absent regular file.
            removed.append(entry['path'])
    mismatches = check(root, snapshot)
    if mismatches:
        raise ValueError(f'restore verification failed: {mismatches}')
    return {'restored': len(ready), 'removed_new_files': removed}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['save', 'check', 'restore'])
    parser.add_argument('--root', default='.')
    parser.add_argument('--snapshot', required=True)
    parser.add_argument('--paths', help='JSON array file; required for save')
    args = parser.parse_args()
    try:
        if args.action == 'save':
            if not args.paths:
                parser.error('save requires --paths')
            result = save(args.root, args.snapshot, json.loads(Path(args.paths).read_text()))
        elif args.action == 'restore':
            result = restore(args.root, args.snapshot)
        else:
            mismatches = check(args.root, args.snapshot)
            result = {'mismatches': mismatches}
            if mismatches:
                print(json.dumps({'ok': False, **result}))
                return 1
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(json.dumps({'ok': False, 'error': str(exc)}))
        return 1
    print(json.dumps({'ok': True, **result}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
