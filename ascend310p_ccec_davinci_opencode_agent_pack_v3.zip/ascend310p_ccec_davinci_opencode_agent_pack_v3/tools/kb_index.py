#!/usr/bin/env python3
"""Index Markdown knowledge cards into SQLite/FTS5.
Uses only the Python standard library. The Markdown files remain the source of truth.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sqlite3
from pathlib import Path
from typing import Any


def parse_value(raw: str) -> Any:
    raw = raw.strip()
    if not raw:
        return ""
    if raw.startswith("[") and raw.endswith("]"):
        try:
            return json.loads(raw.replace("'", '"'))
        except Exception:
            return [x.strip().strip('"\'') for x in raw[1:-1].split(",") if x.strip()]
    if raw.lower() in {"true", "false"}:
        return raw.lower() == "true"
    return raw.strip('"\'')


def parse_frontmatter(text: str) -> tuple[dict[str, Any], str]:
    if not text.startswith("---\n"):
        return {}, text
    end = text.find("\n---\n", 4)
    if end < 0:
        return {}, text
    block = text[4:end]
    body = text[end + 5 :]
    meta: dict[str, Any] = {}
    for line in block.splitlines():
        if not line.strip() or line.lstrip().startswith("#") or ":" not in line:
            continue
        key, value = line.split(":", 1)
        meta[key.strip()] = parse_value(value)
    return meta, body


def flat(meta: dict[str, Any], key: str) -> str:
    value = meta.get(key, "")
    if isinstance(value, list):
        return "|".join(str(x) for x in value)
    return str(value)


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--knowledge", default="knowledge")
    p.add_argument("--db", default=".operator-agent/kb.sqlite")
    args = p.parse_args()

    knowledge = Path(args.knowledge)
    db_path = Path(args.db)
    db_path.parent.mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(db_path)
    conn.execute("DROP TABLE IF EXISTS docs")
    conn.execute(
        """CREATE TABLE docs(
        rowid INTEGER PRIMARY KEY,
        path TEXT UNIQUE,
        id TEXT,
        title TEXT,
        kind TEXT,
        status TEXT,
        soc TEXT,
        architecture TEXT,
        cann TEXT,
        compiler TEXT,
        backend TEXT,
        compatibility TEXT,
        usable_for_codegen TEXT,
        op_family TEXT,
        dtype TEXT,
        layout TEXT,
        trust TEXT,
        tags TEXT,
        content_hash TEXT,
        body TEXT
        )"""
    )
    fts = True
    try:
        conn.execute("DROP TABLE IF EXISTS docs_fts")
        conn.execute(
            "CREATE VIRTUAL TABLE docs_fts USING fts5(path, title, kind, tags, body, content='docs', content_rowid='rowid')"
        )
    except sqlite3.OperationalError:
        fts = False

    count = 0
    for path in sorted(knowledge.rglob("*.md")):
        if "_templates" in path.parts or path.name.lower() in {"readme.md", "index.md"}:
            continue
        text = path.read_text(encoding="utf-8")
        meta, body = parse_frontmatter(text)
        if not meta:
            continue
        digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
        values = (
            str(path), flat(meta, "id"), flat(meta, "title"), flat(meta, "kind"),
            flat(meta, "status"), flat(meta, "soc"), flat(meta, "architecture"), flat(meta, "cann"),
            flat(meta, "compiler"), flat(meta, "backend"), flat(meta, "compatibility"),
            flat(meta, "usable_for_codegen"), flat(meta, "op_family"), flat(meta, "dtype"),
            flat(meta, "layout"), flat(meta, "trust"), flat(meta, "tags"), digest, body,
        )
        cur = conn.execute(
            """INSERT INTO docs(path,id,title,kind,status,soc,architecture,cann,compiler,backend,compatibility,usable_for_codegen,op_family,dtype,layout,trust,tags,content_hash,body)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            values,
        )
        if fts:
            rowid = cur.lastrowid
            conn.execute(
                "INSERT INTO docs_fts(rowid,path,title,kind,tags,body) VALUES (?,?,?,?,?,?)",
                (rowid, str(path), flat(meta, "title"), flat(meta, "kind"), flat(meta, "tags"), body),
            )
        count += 1

    conn.commit()
    conn.close()
    print(json.dumps({"indexed": count, "db": str(db_path), "fts5": fts}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
