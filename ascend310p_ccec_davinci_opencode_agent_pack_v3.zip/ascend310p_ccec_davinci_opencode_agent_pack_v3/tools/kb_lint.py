#!/usr/bin/env python3
"""Lint Markdown KB cards and enforce promotion/code-generation gates."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


REQUIRED = ["id", "kind", "title", "status", "soc", "architecture", "cann", "backend", "trust", "source"]
VALID_KIND = {"api", "golden", "pattern", "failure", "performance", "official", "project"}
VALID_STATUS = {"PROVISIONAL", "VERIFIED", "QUARANTINED", "DEPRECATED"}
VALID_TRUST = {"T0", "T1", "T2", "T3", "T4", "T5", "T6"}
VALID_COMPATIBILITY = {"EXACT", "PROVEN_COMPATIBLE", "CONCEPT_ONLY", "UNKNOWN"}
CODEGEN_TRUST = {"T0", "T1", "T2", "T3", "T4"}


def parse_value(raw: str) -> Any:
    raw = raw.strip()
    if not raw:
        return ""
    if raw.startswith("[") and raw.endswith("]"):
        try:
            return json.loads(raw.replace("'", '"'))
        except (json.JSONDecodeError, TypeError):
            return [item.strip().strip("\"'") for item in raw[1:-1].split(",") if item.strip()]
    if raw.lower() in {"true", "false"}:
        return raw.lower() == "true"
    return raw.strip("\"'")


def parse(text: str) -> dict[str, Any]:
    if not text.startswith("---\n"):
        return {}
    end = text.find("\n---\n", 4)
    if end < 0:
        return {}
    result: dict[str, Any] = {}
    for line in text[4:end].splitlines():
        if ":" in line and not line.lstrip().startswith("#"):
            key, value = line.split(":", 1)
            result[key.strip()] = parse_value(value)
    return result


def tokens(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    if value in (None, ""):
        return []
    return [item.strip() for item in str(value).split("|") if item.strip()]


def has_exact(value: Any, expected: str) -> bool:
    return expected.casefold() in {item.casefold() for item in tokens(value)}


def has_concrete_version(value: Any) -> bool:
    values = {item.upper() for item in tokens(value)}
    return bool(values) and not values.intersection({"UNKNOWN", "ANY", "MULTIPLE", "OTHER"})


def lint_card(path: Path, meta: dict[str, Any]) -> list[str]:
    problems: list[str] = []
    missing = [key for key in REQUIRED if key not in meta or meta[key] in (None, "", [])]
    if missing:
        problems.append(f"missing fields: {missing}")

    kind = str(meta.get("kind", "")).lower()
    status = meta.get("status")
    trust = meta.get("trust")
    compatibility = meta.get("compatibility")
    usable = meta.get("usable_for_codegen", False)

    if kind and kind not in VALID_KIND:
        problems.append(f"invalid kind {kind}")
    if status and status not in VALID_STATUS:
        problems.append(f"invalid status {status}")
    if trust and trust not in VALID_TRUST:
        problems.append(f"invalid trust {trust}")
    if compatibility not in (None, "") and compatibility not in VALID_COMPATIBILITY:
        problems.append(f"invalid compatibility {compatibility}")
    if "usable_for_codegen" in meta and not isinstance(usable, bool):
        problems.append("usable_for_codegen must be true or false")

    if usable is True:
        if status != "VERIFIED":
            problems.append("usable_for_codegen=true requires status VERIFIED")
        if trust not in CODEGEN_TRUST:
            problems.append("usable_for_codegen=true requires trust T0-T4")
        if compatibility not in {"EXACT", "PROVEN_COMPATIBLE"}:
            problems.append("usable_for_codegen=true requires EXACT or PROVEN_COMPATIBLE compatibility")
        if not has_exact(meta.get("soc"), "Ascend310P"):
            problems.append("usable_for_codegen=true requires exact soc Ascend310P")
        if not has_exact(meta.get("architecture"), "DaVinci"):
            problems.append("usable_for_codegen=true requires architecture DaVinci")
        if not has_exact(meta.get("backend"), "cce-c"):
            problems.append("usable_for_codegen=true requires backend cce-c")
        if not has_concrete_version(meta.get("cann")):
            problems.append("usable_for_codegen=true requires a concrete CANN version")
        if not has_concrete_version(meta.get("compiler")):
            problems.append("usable_for_codegen=true requires a concrete compiler version")
        if not tokens(meta.get("verification")):
            problems.append("usable_for_codegen=true requires verification evidence IDs")

    if kind == "golden" and status == "VERIFIED":
        for gate in ("build", "accuracy", "board"):
            if meta.get(gate) != "PASS":
                problems.append(f"VERIFIED golden requires {gate}=PASS")
        if not has_exact(meta.get("soc"), "Ascend310P"):
            problems.append("VERIFIED golden requires exact soc Ascend310P")
        if not has_exact(meta.get("architecture"), "DaVinci") or not has_exact(meta.get("backend"), "cce-c"):
            problems.append("VERIFIED golden requires DaVinci and cce-c")
        if not has_concrete_version(meta.get("cann")) or not has_concrete_version(meta.get("compiler")):
            problems.append("VERIFIED golden requires concrete CANN and compiler versions")
        if not tokens(meta.get("verification")):
            problems.append("VERIFIED golden requires verification evidence IDs")

    if kind == "performance" and status == "VERIFIED":
        required = [
            "compiler",
            "source_revision",
            "before_latency",
            "after_latency",
            "profiler_evidence",
            "optimization_change",
            "decision",
        ]
        perf_missing = [key for key in required if meta.get(key) in (None, "", [])]
        if perf_missing:
            problems.append(f"VERIFIED performance card missing fields: {perf_missing}")
        if not has_exact(meta.get("soc"), "Ascend310P"):
            problems.append("VERIFIED performance card requires exact soc Ascend310P")
        if not has_exact(meta.get("architecture"), "DaVinci") or not has_exact(meta.get("backend"), "cce-c"):
            problems.append("VERIFIED performance card requires DaVinci and cce-c")
        if not has_concrete_version(meta.get("cann")) or not has_concrete_version(meta.get("compiler")):
            problems.append("VERIFIED performance card requires concrete CANN and compiler versions")
        if meta.get("decision") not in {"KEEP", "REVERT"}:
            problems.append("VERIFIED performance card decision must be KEEP or REVERT")

    return problems


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--knowledge", default="knowledge")
    args = parser.parse_args()
    problems: list[dict[str, str]] = []
    seen: dict[str, str] = {}
    knowledge = Path(args.knowledge)
    if not knowledge.is_dir():
        problems.append({"path": str(knowledge), "error": "knowledge directory not found"})
    else:
        for path in sorted(knowledge.rglob("*.md")):
            if "_templates" in path.parts or path.name.lower() in {"readme.md", "index.md"}:
                continue
            meta = parse(path.read_text(encoding="utf-8"))
            if not meta:
                problems.append({"path": str(path), "error": "missing frontmatter"})
                continue
            for error in lint_card(path, meta):
                problems.append({"path": str(path), "error": error})
            card_id = meta.get("id")
            if card_id:
                card_id = str(card_id)
                if card_id in seen:
                    problems.append({"path": str(path), "error": f"duplicate id also in {seen[card_id]}"})
                else:
                    seen[card_id] = str(path)
    print(json.dumps({"ok": not problems, "problems": problems}, indent=2, ensure_ascii=False))
    return 1 if problems else 0


if __name__ == "__main__":
    raise SystemExit(main())
