#!/usr/bin/env python3
"""Query the KB with compatibility filters before trust and text ranking."""
from __future__ import annotations

import argparse
import json
import sqlite3
from pathlib import Path
from typing import Any


FILTER_COLUMNS = {
    "soc": "soc",
    "architecture": "architecture",
    "cann": "cann",
    "compiler": "compiler",
    "backend": "backend",
    "family": "op_family",
    "dtype": "dtype",
    "layout": "layout",
}


def add_filter(
    where: list[str], params: list[str], column: str, value: str | None, allow_unknown: bool
) -> None:
    if not value:
        return
    exact = f"({column} = ? OR {column} LIKE ? OR {column} LIKE ? OR {column} LIKE ?)"
    clause = exact
    if allow_unknown:
        clause = (
            f"({exact} OR {column} = 'ANY' OR {column} = 'UNKNOWN' "
            f"OR {column} LIKE 'ANY|%' OR {column} LIKE '%|ANY' OR {column} LIKE '%|ANY|%' "
            f"OR {column} LIKE 'UNKNOWN|%' OR {column} LIKE '%|UNKNOWN' OR {column} LIKE '%|UNKNOWN|%')"
        )
    where.append(clause)
    params.extend([value, f"{value}|%", f"%|{value}", f"%|{value}|%"])


def split_tokens(value: Any) -> set[str]:
    return {item.strip().casefold() for item in str(value or "").split("|") if item.strip()}


def dimension_penalty(row: dict[str, Any], args: argparse.Namespace) -> int:
    penalty = 0
    for arg_name, column in FILTER_COLUMNS.items():
        expected = getattr(args, arg_name)
        if not expected:
            continue
        values = split_tokens(row.get(column))
        if expected.casefold() in values:
            continue
        if "any" in values:
            penalty += 2
        elif "unknown" in values:
            penalty += 3
        else:
            penalty += 10
    return penalty


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("query")
    parser.add_argument("--db", default=".operator-agent/kb.sqlite")
    parser.add_argument("--soc")
    parser.add_argument("--architecture")
    parser.add_argument("--cann")
    parser.add_argument("--compiler")
    parser.add_argument("--backend")
    parser.add_argument("--usable-for-codegen", choices=["true", "false"])
    parser.add_argument("--family")
    parser.add_argument("--dtype")
    parser.add_argument("--layout")
    parser.add_argument("--status", default="VERIFIED,PROVISIONAL")
    parser.add_argument("--limit", type=int, default=20)
    parser.add_argument(
        "--include-unknown-dimensions",
        action="store_true",
        help="include ANY/UNKNOWN dimension cards as lower-ranked conceptual clues; forbidden for code generation",
    )
    args = parser.parse_args()

    if args.limit < 1:
        raise SystemExit("--limit must be positive")
    if args.usable_for_codegen == "true" and args.include_unknown_dimensions:
        raise SystemExit("code-generation queries cannot include ANY/UNKNOWN dimensions")

    db = Path(args.db)
    if not db.exists():
        raise SystemExit(f"KB index not found: {db}. Run tools/kb_index.py first.")
    conn = sqlite3.connect(db)
    conn.row_factory = sqlite3.Row

    where: list[str] = []
    params: list[str] = []
    statuses = [status.strip() for status in args.status.split(",") if status.strip()]
    if statuses:
        where.append("status IN (%s)" % ",".join("?" for _ in statuses))
        params.extend(statuses)

    for arg_name, column in FILTER_COLUMNS.items():
        add_filter(where, params, column, getattr(args, arg_name), args.include_unknown_dimensions)

    if args.usable_for_codegen is not None:
        where.append("lower(usable_for_codegen) = ?")
        params.append(args.usable_for_codegen)
    if args.usable_for_codegen == "true":
        where.extend(
            [
                "status = 'VERIFIED'",
                "trust IN ('T0','T1','T2','T3','T4')",
                "compatibility IN ('EXACT','PROVEN_COMPATIBLE')",
            ]
        )

    where_sql = " AND ".join(where) if where else "1=1"
    rows: list[sqlite3.Row] = []
    fts_exists = conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='docs_fts'").fetchone()
    if fts_exists:
        try:
            sql = f"""
                SELECT d.*, bm25(docs_fts) AS text_score
                FROM docs_fts
                JOIN docs d ON d.rowid = docs_fts.rowid
                WHERE docs_fts MATCH ? AND {where_sql}
            """
            rows = conn.execute(sql, [args.query, *params]).fetchall()
        except sqlite3.OperationalError:
            rows = []

    if not rows:
        terms = [term for term in args.query.replace('"', " ").split() if term]
        text_clause = " AND ".join("(title LIKE ? OR body LIKE ? OR tags LIKE ?)" for _ in terms) or "1=1"
        text_params: list[str] = []
        for term in terms:
            like = f"%{term}%"
            text_params.extend([like, like, like])
        sql = f"SELECT *, 0 AS text_score FROM docs WHERE {where_sql} AND {text_clause}"
        rows = conn.execute(sql, [*params, *text_params]).fetchall()

    trust_rank = {"T0": 0, "T1": 1, "T2": 2, "T3": 3, "T4": 4, "T5": 5, "T6": 6}
    compatibility_rank = {"EXACT": 0, "PROVEN_COMPATIBLE": 1, "UNKNOWN": 3, "CONCEPT_ONLY": 4}
    result = [dict(row) for row in rows]
    result.sort(
        key=lambda row: (
            dimension_penalty(row, args),
            compatibility_rank.get(row.get("compatibility", "UNKNOWN"), 3),
            trust_rank.get(row.get("trust", "T6"), 99),
            row.get("text_score", 0),
            row.get("id", ""),
        )
    )
    for row in result:
        row.pop("body", None)
    print(json.dumps(result[: args.limit], indent=2, ensure_ascii=False))
    conn.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
