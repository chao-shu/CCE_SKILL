#!/usr/bin/env python3
"""Offline behavioral regressions; synthetic fixtures are not 310P hardware evidence."""
import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from validate_stage_report import file_hash, validate
from kb_dedupe import cards, find_overlaps
from optimization_checkpoint import save, restore, check

TOOLS = Path(__file__).resolve().parent


class WorkflowGates(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='cce-gates-')
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def write(self, name, text):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding='utf-8')
        return path

    def run_tool(self, tool, *args):
        return subprocess.run([sys.executable, str(TOOLS/tool), *map(str,args)],
                              cwd=self.root, capture_output=True, text=True)

    def report(self):
        self.write('source.cce', 'synthetic input')
        self.write('result.json', '{"measured": false}')
        self.write('build.log', 'synthetic test evidence')
        return {'run_id':'run-1', 'stage':'build', 'status':'PASS',
                'inputs':['source.cce'], 'input_hashes':{'source.cce':file_hash(self.root/'source.cce')},
                'outputs':['result.json'], 'output_hashes':{'result.json':file_hash(self.root/'result.json')},
                'evidence':[{'path':'build.log','sha256':file_hash(self.root/'build.log')}],
                'assumptions':[], 'warnings':[], 'blockers':[],
                'failure_class':None, 'recommended_next_stage':'accuracy'}

    def test_report_integrity_and_run_identity(self):
        report = self.report()
        self.assertEqual(validate(report,'build',root=self.root,expected_run_id='run-1'), [])
        self.assertTrue(validate(report,'build',root=self.root,expected_run_id='other-run'))
        bad = copy.deepcopy(report)
        bad['input_hashes'] = {'unrelated.txt':'not-a-hash'}
        self.assertTrue(validate(bad,'build',root=self.root))
        self.write('source.cce','modified after build')
        self.assertTrue(validate(report,'build',root=self.root))

    def test_missing_and_changed_evidence_and_outputs(self):
        report = self.report()
        self.write('build.log','different candidate')
        self.assertTrue(validate(report,root=self.root))
        report = self.report()
        (self.root/'result.json').unlink()
        self.assertTrue(validate(report,root=self.root))
        report = self.report()
        self.write('result.json','different result')
        self.assertTrue(validate(report,root=self.root))
        report = self.report()
        (self.root/'build.log').unlink()
        self.assertTrue(validate(report,root=self.root))

    def test_cli_checks_state_and_filename(self):
        report = self.report()
        path = self.write('runs/run-1/stage_reports/build.json',json.dumps(report))
        self.write('runs/run-1/state.json',json.dumps({'run_id':'run-1'}))
        self.assertEqual(self.run_tool('validate_stage_report.py',path).returncode,0)
        report['run_id'] = 'older-run'
        path.write_text(json.dumps(report))
        self.assertNotEqual(self.run_tool('validate_stage_report.py',path).returncode,0)

    def test_blocked_and_not_run_remain_valid(self):
        report = self.report()
        report.update(inputs=[],input_hashes={},outputs=[],output_hashes={},evidence=[],status='BLOCKED',blockers=['toolchain absent'])
        self.assertEqual(validate(report,root=self.root),[])
        report.update(status='NOT_RUN',blockers=[])
        self.assertEqual(validate(report,root=self.root),[])
        report.update(status='PASS')
        self.assertTrue(validate(report,root=self.root))

    def card(self, name, card_id, compiler='compiler_A', cann='cann_A', body='Test-only identical fact.', directory='knowledge'):
        meta = {'id':card_id,'title':'test_only_copy','kind':'api','status':'VERIFIED',
                'soc':['Ascend310P'],'architecture':['DaVinci'],'cann':[cann],
                'compiler':[compiler],'backend':['cce-c'],'trust':'T0','compatibility':'EXACT',
                'usable_for_codegen':True,'verification':['synthetic-fixture'],
                'source':'synthetic, not hardware evidence','symbol':['test_only_copy']}
        text = '---\n'+'\n'.join(f'{k}: {json.dumps(v)}' for k,v in meta.items())+'\n---\n'+body+'\n'
        return self.write(f'{directory}/{name}.md',text)

    def test_duplicate_fact_blocks_lint_even_with_new_id(self):
        self.card('a','TEST-A')
        self.card('b','TEST-B')
        self.assertNotEqual(self.run_tool('kb_lint.py').returncode,0)
        pairs=find_overlaps(cards(self.root/'knowledge'))
        self.assertEqual(pairs[0]['reason'],'EXACT_DUPLICATE')

    def test_distinct_version_and_constraint_preserved(self):
        self.card('a','TEST-A')
        self.card('b','TEST-B',compiler='compiler_B')
        self.card('c','TEST-C',body='Different test-only overload constraint.')
        self.assertEqual(self.run_tool('kb_lint.py').returncode,0)
        pairs=find_overlaps(cards(self.root/'knowledge'))
        self.assertTrue(pairs)
        self.assertTrue(all(p['reason']=='SCOPE_OVERLAP_REVIEW' for p in pairs))

    def test_candidate_against_existing(self):
        self.card('a','TEST-A')
        self.card('b','TEST-B',directory='candidates')
        result=self.run_tool('kb_dedupe.py','--knowledge','candidates','--against','knowledge')
        self.assertEqual(result.returncode,1)
        self.assertEqual(json.loads(result.stdout)['pairs'][0]['reason'],'EXACT_DUPLICATE')

    def test_codegen_requires_fingerprint_and_filters_versions(self):
        self.card('a','TEST-A')
        self.card('b','TEST-B',compiler='compiler_B')
        self.assertEqual(self.run_tool('kb_index.py').returncode,0)
        common=['test_only_copy','--usable-for-codegen','true','--soc','Ascend310P','--backend','cce-c']
        self.assertNotEqual(self.run_tool('kb_query.py',*common).returncode,0)
        full=common+['--architecture','DaVinci','--cann','cann_A','--compiler','compiler_A']
        result=self.run_tool('kb_query.py',*full)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertEqual([r['id'] for r in json.loads(result.stdout)],['TEST-A'])
        full[-1]='UNKNOWN'
        self.assertNotEqual(self.run_tool('kb_query.py',*full).returncode,0)
        full[-1]='compiler_missing'
        self.assertEqual(json.loads(self.run_tool('kb_query.py',*full).stdout),[])
        result=self.run_tool('kb_query.py','test_only_copy','--include-unknown-dimensions')
        self.assertEqual(result.returncode,0,result.stderr)

    def test_query_underscore_is_not_a_wildcard(self):
        self.card('a','TEST-A',compiler='compilerXA|compiler_other')
        self.assertEqual(self.run_tool('kb_index.py').returncode,0)
        result=self.run_tool('kb_query.py','test_only_copy','--usable-for-codegen','true',
                             '--soc','Ascend310P','--architecture','DaVinci','--cann','cann_A',
                             '--compiler','compiler_A','--backend','cce-c')
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertEqual(json.loads(result.stdout),[])

    def test_restore_code_design_reports_and_new_files(self):
        report=self.report()
        self.write('stage.json',json.dumps(report))
        self.write('design.json','accepted design')
        self.write('unrelated.txt','user changes')
        names=['source.cce','result.json','build.log','stage.json','design.json','new.cce']
        snapshot=self.root/'snapshots/accepted'
        save(self.root,snapshot,names)
        for name in names:
            self.write(name,'rejected candidate')
        save(self.root,self.root/'snapshots/rejected',names)
        self.assertTrue(check(self.root,snapshot))
        restore(self.root,snapshot)
        self.assertEqual(check(self.root,snapshot),[])
        self.assertEqual(validate(json.loads((self.root/'stage.json').read_text()),root=self.root),[])
        self.assertFalse((self.root/'new.cce').exists())
        self.assertEqual((self.root/'unrelated.txt').read_text(),'user changes')
        self.assertTrue((self.root/'snapshots/rejected/manifest.json').exists())

    def test_corrupted_checkpoint_and_unsafe_path_refused_before_write(self):
        self.write('source.cce','accepted')
        snapshot=self.root/'snapshots/accepted'
        save(self.root,snapshot,['source.cce'])
        self.write('source.cce','candidate')
        (snapshot/'0.bin').write_text('corrupted')
        with self.assertRaises(ValueError):
            restore(self.root,snapshot)
        self.assertEqual((self.root/'source.cce').read_text(),'candidate')
        with self.assertRaises(ValueError):
            save(self.root,self.root/'snapshots/unsafe',['../outside.cce'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
