#!/usr/bin/env python3
"""Read-only discovery helper for CCE-C repositories/environments."""
from pathlib import Path
import shutil, subprocess, os, json

def cmd(args):
    try:
        p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=8)
        return {'cmd':args,'rc':p.returncode,'out':p.stdout[:8000]}
    except Exception as e:
        return {'cmd':args,'error':repr(e)}

out={'executables':{},'env':{},'cce_files':[],'probes':[]}
for exe in ['ccec','bisheng','npu-smi','msprof']:
    out['executables'][exe]=shutil.which(exe)
for k in ['ASCEND_HOME','ASCEND_HOME_PATH','ASCEND_TOOLKIT_HOME','PATH','LD_LIBRARY_PATH']:
    if k in os.environ: out['env'][k]=os.environ[k]
for p in Path('.').rglob('*.cce'):
    if '.git' not in p.parts and len(out['cce_files'])<500:
        out['cce_files'].append(str(p))
for exe in ['ccec','bisheng']:
    if out['executables'].get(exe): out['probes'].append(cmd([exe,'--version']))
if out['executables'].get('npu-smi'): out['probes'].append(cmd(['npu-smi','info']))
print(json.dumps(out,indent=2,ensure_ascii=False))
