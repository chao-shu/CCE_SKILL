#!/usr/bin/env python3
"""Validate the complete stage-report contract."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


REQUIRED = [
    "run_id",
    "stage",
    "status",
    "inputs",
    "input_hashes",
    "outputs",
    "evidence",
    "assumptions",
    "warnings",
    "blockers",
    "failure_class",
    "recommended_next_stage",
]
VALID_STATUS = {"PASS", "FAIL", "BLOCKED", "NOT_RUN"}
LIST_FIELDS = {"inputs", "outputs", "evidence", "assumptions", "warnings", "blockers"}


def validate(obj: Any, expected_stage: str | None = None) -> list[str]:
    if not isinstance(obj, dict):
        return ["report root must be a JSON object"]

    problems: list[str] = []
    missing = [key for key in REQUIRED if key not in obj]
    if missing:
        problems.append("missing fields: " + ", ".join(missing))

    for key in ("run_id", "stage"):
        if key in obj and (not isinstance(obj[key], str) or not obj[key].strip()):
            problems.append(f"{key} must be a non-empty string")

    status = obj.get("status")
    if status not in VALID_STATUS:
        problems.append(f"invalid status: {status!r}")

    for key in LIST_FIELDS:
        if key in obj and not isinstance(obj[key], list):
            problems.append(f"{key} must be an array")
    if "input_hashes" in obj and not isinstance(obj["input_hashes"], dict):
        problems.append("input_hashes must be an object")
    if isinstance(obj.get("inputs"), list) and obj.get("inputs") and not obj.get("input_hashes"):
        problems.append("non-empty inputs require input_hashes")

    if expected_stage and obj.get("stage") != expected_stage:
        problems.append(f"stage must be {expected_stage!r}, got {obj.get('stage')!r}")

    if status == "PASS":
        if not obj.get("evidence"):
            problems.append("PASS requires at least one evidence item")
        if not obj.get("outputs"):
            problems.append("PASS requires at least one output")
        if obj.get("blockers"):
            problems.append("PASS cannot contain blockers")
        if obj.get("failure_class") not in (None, ""):
            problems.append("PASS cannot contain failure_class")
    elif status == "FAIL":
        if obj.get("failure_class") in (None, ""):
            problems.append("FAIL requires failure_class")
        if not obj.get("evidence"):
            problems.append("FAIL requires failure evidence")
    elif status == "BLOCKED":
        if not obj.get("blockers"):
            problems.append("BLOCKED requires at least one blocker")

    return problems


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("path")
    parser.add_argument("--expected-stage")
    args = parser.parse_args()

    try:
        obj = json.loads(Path(args.path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"FAIL invalid report: {exc}")
        return 1

    problems = validate(obj, args.expected_stage)
    if problems:
        print(json.dumps({"ok": False, "problems": problems}, indent=2, ensure_ascii=False))
        return 1
    print(json.dumps({"ok": True}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
