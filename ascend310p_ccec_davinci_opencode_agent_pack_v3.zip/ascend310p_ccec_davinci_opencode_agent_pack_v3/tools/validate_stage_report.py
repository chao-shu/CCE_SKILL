#!/usr/bin/env python3
"""Validate report structure, run identity and referenced file SHA-256 values."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path
from typing import Any

REQUIRED = {
    'run_id', 'stage', 'status', 'inputs', 'input_hashes', 'outputs',
    'output_hashes', 'evidence', 'assumptions', 'warnings', 'blockers',
    'failure_class', 'recommended_next_stage',
}
VALID_STATUS = {'PASS', 'FAIL', 'BLOCKED', 'NOT_RUN'}
LIST_FIELDS = {'inputs', 'outputs', 'evidence', 'assumptions', 'warnings', 'blockers'}


def file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def validate(obj: Any, expected_stage: str | None = None, *,
             root: Path | None = None, expected_run_id: str | None = None) -> list[str]:
    if not isinstance(obj, dict):
        return ['report root must be a JSON object']
    root = Path.cwd() if root is None else Path(root)
    problems = []
    missing = REQUIRED - obj.keys()
    if missing:
        problems.append('missing fields: ' + ', '.join(sorted(missing)))
    for key in ('run_id', 'stage'):
        if not isinstance(obj.get(key), str) or not obj[key].strip():
            problems.append(f'{key} must be a non-empty string')
    status = obj.get('status')
    if not isinstance(status, str) or status not in VALID_STATUS:
        problems.append(f'invalid status: {status!r}')
    for key in LIST_FIELDS:
        if not isinstance(obj.get(key), list):
            problems.append(f'{key} must be an array')
    if expected_stage is not None and obj.get('stage') != expected_stage:
        problems.append(f'stage must be {expected_stage!r}')
    if expected_run_id is not None and obj.get('run_id') != expected_run_id:
        problems.append(f'run_id must be {expected_run_id!r}')

    def check_file(name: Any, digest: Any, context: str) -> None:
        if not isinstance(name, str) or not name.strip():
            problems.append(f'{context}: path must be a non-empty string')
            return
        if not isinstance(digest, str) or not re.fullmatch(r'(sha256:)?[0-9a-fA-F]{64}', digest):
            problems.append(f'{context}: invalid SHA-256 for {name}')
            return
        path = Path(name)
        if not path.is_absolute():
            path = root / path
        try:
            if not path.is_file():
                problems.append(f'{context}: missing file {name}')
            elif file_hash(path) != digest.removeprefix('sha256:').lower():
                problems.append(f'{context}: hash mismatch {name}')
        except OSError as exc:
            problems.append(f'{context}: cannot read {name}: {exc}')

    for key, hashes_key in [('inputs', 'input_hashes'), ('outputs', 'output_hashes')]:
        names, hashes = obj.get(key), obj.get(hashes_key)
        if not isinstance(hashes, dict):
            problems.append(f'{hashes_key} must be an object')
            continue
        if not isinstance(names, list):
            continue
        if any(not isinstance(name, str) or not name.strip() for name in names):
            problems.append(f'{key} must contain non-empty file paths')
            continue
        if len(set(names)) != len(names):
            problems.append(f'{key} contains duplicate paths')
        if set(names) != set(hashes):
            problems.append(f'{hashes_key} keys must exactly match {key}')
        for name in names:
            check_file(name, hashes.get(name), key)
    evidence = obj.get('evidence')
    if isinstance(evidence, list):
        for item in evidence:
            if not isinstance(item, dict):
                problems.append('evidence items must contain path and sha256')
            else:
                check_file(item.get('path'), item.get('sha256'), 'evidence')
    if status == 'PASS':
        if not evidence:
            problems.append('PASS requires evidence')
        if not obj.get('outputs'):
            problems.append('PASS requires output files')
        if obj.get('blockers') or obj.get('failure_class') not in (None, ''):
            problems.append('PASS cannot contain blockers or failure_class')
    elif status == 'FAIL':
        if not isinstance(obj.get('failure_class'), str) or not obj['failure_class'].strip():
            problems.append('FAIL requires failure_class')
        if not evidence:
            problems.append('FAIL requires failure evidence')
    elif status == 'BLOCKED' and not obj.get('blockers'):
        problems.append('BLOCKED requires concrete blockers')
    return problems


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('path')
    parser.add_argument('--expected-stage')
    parser.add_argument('--root', default='.', help='base of relative paths; normally project root')
    parser.add_argument('--run-dir', help='defaults to parent of stage_reports/')
    args = parser.parse_args()
    try:
        report_path = Path(args.path).resolve()
        run_dir = Path(args.run_dir).resolve() if args.run_dir else report_path.parent.parent
        if report_path.parent != run_dir / 'stage_reports':
            raise ValueError('report must be under RUN_DIR/stage_reports/')
        state = json.loads((run_dir / 'state.json').read_text(encoding='utf-8'))
        run_id = state.get('run_id')
        if not isinstance(run_id, str) or run_id != run_dir.name:
            raise ValueError('state.json run_id must match RUN_DIR name')
        obj = json.loads(report_path.read_text(encoding='utf-8'))
        expected_stage = args.expected_stage or report_path.stem
        if report_path.stem != expected_stage:
            raise ValueError('report filename must match expected stage')
        problems = validate(obj, expected_stage, root=Path(args.root), expected_run_id=run_id)
    except (OSError, ValueError, AttributeError) as exc:
        problems = [str(exc)]
    print(json.dumps({'ok': not problems, 'problems': problems}, indent=2, ensure_ascii=False))
    return 1 if problems else 0


if __name__ == '__main__':
    raise SystemExit(main())
