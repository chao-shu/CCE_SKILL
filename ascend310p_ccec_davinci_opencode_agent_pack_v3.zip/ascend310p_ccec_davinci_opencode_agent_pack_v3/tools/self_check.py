#!/usr/bin/env python3
from pathlib import Path
import re, json, subprocess, sys, tempfile
from kb_lint import REQUIRED as KB_REQUIRED, lint_card, parse as parse_kb
from validate_stage_report import validate as validate_stage_report
root=Path(__file__).resolve().parents[1]
problems=[]
skill_root=root/'.opencode/skills'
skills=[]
for d in sorted(skill_root.iterdir()):
    if not d.is_dir(): continue
    p=d/'SKILL.md'
    if not p.exists():
        problems.append(f'missing {p.relative_to(root)}'); continue
    text=p.read_text(encoding='utf-8')
    m=re.search(r'^name:\s*([^\n]+)$',text,re.M)
    name=m.group(1).strip().strip('"\'') if m else None
    if name!=d.name: problems.append(f'name mismatch: {d.name} != {name}')
    if re.search(r'target:\s*["\']?Ascend(?: )?310(?!P)',text):
        problems.append(f'non-310P target residue in {p.relative_to(root)}')
    skills.append(name)
if len(skills)!=16: problems.append(f'expected 16 skills, got {len(skills)}')

report_paths={
 'ascend310p-ccec-environment':'stage_reports/environment.json',
 'ascend310p-ccec-repo-context':'stage_reports/repo_context.json',
 'ascend310p-ccec-semantic-analysis':'stage_reports/semantics.json',
 'ascend310p-ccec-kb-retrieval':'stage_reports/kb_retrieval.json',
 'ascend310p-ccec-test-generation':'stage_reports/test_generation.json',
 'ascend310p-ccec-davinci-design':'stage_reports/davinci_design.json',
 'ascend310p-ccec-baseline-codegen':'stage_reports/baseline_codegen.json',
 'ascend310p-ccec-build-debug':'stage_reports/build.json',
 'ascend310p-ccec-accuracy-validation':'stage_reports/accuracy.json',
 'ascend310p-ccec-profiling':'stage_reports/profiling.json',
 'ascend310p-ccec-performance-optimization':'stage_reports/performance_optimization.json',
 'ascend310p-ccec-regression':'stage_reports/regression.json',
 'ascend310p-ccec-release-audit':'stage_reports/release_audit.json',
 'ascend310p-ccec-kb-curation':'stage_reports/kb_curation.json',
 'ascend310p-ccec-kb-ingestion':'stage_reports/kb_ingestion.json',
}
for skill, report_path in report_paths.items():
    text=(skill_root/skill/'SKILL.md').read_text(encoding='utf-8')
    if report_path not in text:
        problems.append(f'{skill} does not declare {report_path}')

for route_file in [root/'AGENTS.md',root/'WORKFLOW_MAP.md',skill_root/'ascend310p-ccec-operator-orchestrator'/'SKILL.md']:
    if 'kb-ingestion' in route_file.read_text(encoding='utf-8').lower():
        problems.append(f'independent kb-ingestion appears in operator route: {route_file.relative_to(root)}')

lint=subprocess.run([sys.executable,str(root/'tools/kb_lint.py'),'--knowledge',str(root/'knowledge')],capture_output=True,text=True)
if lint.returncode!=0: problems.append('KB lint failed: '+lint.stdout+lint.stderr)

for template in sorted((root/'knowledge/_templates').glob('*.md')):
    meta=parse_kb(template.read_text(encoding='utf-8'))
    absent=[key for key in KB_REQUIRED if key not in meta]
    if absent: problems.append(f'{template.relative_to(root)} missing template fields: {absent}')

minimal={'stage':'semantics','status':'PASS'}
if not validate_stage_report(minimal):
    problems.append('stage-report validator accepted an incomplete PASS report')
valid_report={
 'run_id':'self-check','stage':'semantics','status':'PASS','inputs':['reference.py'],
 'input_hashes':{'reference.py':'sha256:self-check'},'outputs':['semantic_spec.json'],
 'evidence':['reference.py'],'assumptions':[],'warnings':[],'blockers':[],
 'failure_class':None,'recommended_next_stage':'kb_retrieval'
}
if validate_stage_report(valid_report,'semantics'):
    problems.append('stage-report validator rejected a complete PASS report')

unsafe_codegen={
 'id':'SELF-CHECK','kind':'api','title':'unsafe','status':'PROVISIONAL','soc':['UNKNOWN'],
 'architecture':['DaVinci'],'cann':['UNKNOWN'],'compiler':['UNKNOWN'],'backend':['cce-c'],
 'trust':'T6','source':'self-check','compatibility':'UNKNOWN','usable_for_codegen':True,
 'verification':[]
}
if not lint_card(Path('self-check.md'),unsafe_codegen):
    problems.append('KB lint accepted unsafe usable_for_codegen evidence')

result={'ok':not problems,'skill_count':len(skills),'problems':problems}
print(json.dumps(result,indent=2,ensure_ascii=False))
raise SystemExit(0 if not problems else 1)
