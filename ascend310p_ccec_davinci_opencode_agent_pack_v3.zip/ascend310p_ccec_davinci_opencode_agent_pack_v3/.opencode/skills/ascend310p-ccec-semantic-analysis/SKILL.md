---
name: ascend310p-ccec-semantic-analysis
description: Convert the Python reference implementation into an implementation-independent mathematical, shape, dtype and numerical contract before any DaVinci/CCE-C design work.
metadata:
  compatibility: "opencode"
  target: "Ascend 310P"
  stage: "semantic analysis"
---

# Mission

Determine exactly **what** the Python implementation computes.

Read the complete reference function and directly relevant helpers/callers/tests. Do not start CCE-C design yet.

# Extract

For each input/output determine:

- dtype;
- rank and shape constraints;
- dynamic dimensions;
- layout/contiguity assumptions;
- broadcasting;
- indexing;
- reduction axes;
- type promotion/casts;
- intermediate precision;
- rounding/truncation;
- saturation/overflow if applicable;
- NaN/Inf behavior;
- domain restrictions;
- alias/in-place expectations;
- edge conditions.

Describe the math as an ordered semantic IR that another engineer could implement without rereading Python.

# Output

Write `RUN_DIR/semantic_spec.json` following `contracts/SEMANTIC_SPEC.md`.

No CCE-C intrinsic, UB offset, DMA, mask, event, tile size or core count may appear as a semantic requirement unless it is itself part of the public operator contract.

Also write `RUN_DIR/stage_reports/semantics.json` according to `contracts/STAGE_REPORT.md` and validate it with `tools/validate_stage_report.py`.
