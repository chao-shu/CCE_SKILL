# KB Ingestion Output Contract

`RUN_DIR/kb_ingestion_report.json` is the auditable record of a knowledge-ingestion run.

## Minimum structure

```json
{
  "run_id": "",
  "stage": "kb_ingestion",
  "status": "PASS|FAIL|BLOCKED|NOT_RUN",
  "mode": "OPERATOR_DIR|PDF|HYBRID",
  "target": {
    "requested_soc": "Ascend310P",
    "detected_soc": null,
    "architecture": "DaVinci",
    "backend": "CCE-C",
    "cann_version": null,
    "compiler": null,
    "compiler_version": null
  },
  "inputs": [],
  "evidence_ledger": [],
  "cards": {
    "created": [],
    "updated": [],
    "promoted": [],
    "quarantined": [],
    "skipped": [],
    "conflicts": []
  },
  "validation": {
    "preexisting_kb_lint": "PASS|FAIL|NOT_RUN",
    "candidate_lint": "PASS|FAIL|NOT_RUN",
    "candidate_index_build": "PASS|FAIL|NOT_RUN",
    "candidate_queries": [],
    "full_kb_lint": "PASS|FAIL|NOT_RUN",
    "canonical_index_build": "PASS|FAIL|NOT_RUN",
    "post_promotion_queries": [],
    "rollback": "PASS|FAIL|NOT_RUN"
  },
  "assumptions": [],
  "warnings": [],
  "blockers": [],
  "next_verification_actions": []
}
```

## Input record

Each operator directory or PDF input should contain:

```json
{
  "kind": "operator_dir|pdf",
  "path": "",
  "sha256": null,
  "git_commit": null,
  "git_dirty": null,
  "size_bytes": null,
  "document_scope": null
}
```

For a directory, use the inventory file and individual file hashes rather than inventing a directory hash.

## Evidence record

Every promoted consequential fact must be traceable:

```json
{
  "evidence_id": "",
  "fact": "",
  "trust": "T0|T1|T2|T3|T4|T5|T6",
  "compatibility": "EXACT|PROVEN_COMPATIBLE|CONCEPT_ONLY|UNKNOWN",
  "source_path": "",
  "source_hash": "",
  "source_location": "file:line or PDF page/section",
  "verification": [],
  "usable_for_codegen": false
}
```

## Card destinations

| Card kind | Destination |
|---|---|
| API | `knowledge/api/` |
| Golden Operator | `knowledge/golden-operators/` |
| Pattern | `knowledge/patterns/` |
| Failure | `knowledge/failures/` |
| Performance | `knowledge/performance/` |
| Project convention | `knowledge/project/` |
| Official reference | `knowledge/official/` |
| Local-document metadata | `knowledge/local-docs/` |
| Unresolved/cross-generation | `knowledge/quarantine/` |

Use stable, unique card IDs. Do not replace an existing card merely because the title or symbol matches; compare target, version, signature, hash, and constraints first.

## Status meaning

- `PASS`: inputs were inventoried, applicable cards were generated, conflicts were handled, and KB validation passed. Some cards may legitimately remain provisional or quarantined.
- `FAIL`: the Skill produced invalid cards, corrupted consistency, or could not complete required validation.
- `BLOCKED`: required input access, PDF readability, target/version identification, or write authorization was unavailable.
- `NOT_RUN`: ingestion was intentionally not executed.

`PASS` requires both candidate validation and complete-KB post-promotion validation. Validation of the pre-existing `knowledge/` tree alone is not evidence that new candidates are valid.
