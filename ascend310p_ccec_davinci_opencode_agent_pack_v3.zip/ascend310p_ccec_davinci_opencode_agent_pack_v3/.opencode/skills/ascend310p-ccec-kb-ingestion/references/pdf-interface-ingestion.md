# PDF Interface-Document Ingestion

Use this mode for interface specifications, compiler manuals, intrinsic references, programming guides, or product documentation supplied as PDFs.

## Document fingerprint

Before extracting facts, record:

- file name, size, and SHA-256;
- document title and edition;
- publisher;
- publication/revision date;
- product and SoC support scope;
- CANN/CCE/compiler version scope;
- language;
- whether text is native or OCR-derived;
- local path or approved source URL.

If target or version scope is missing, compatibility is `UNKNOWN` until corroborated.

## Extraction method

Extract the table of contents and relevant pages first. Use page-aware text extraction. For scanned pages, use OCR only when necessary and record that the result is OCR-derived; visually verify symbols, underscores, punctuation, operators, tables, subscripts, and numeric limits before creating an API card.

Do not treat search snippets, generated summaries, or OCR output as the authoritative wording when the rendered page is available.

## Per-interface facts

Capture applicable:

- exact symbol, overload, declaration, or syntax;
- parameter name, direction, type, unit, valid range, and default;
- source/destination address spaces;
- supported dtypes and format/layout constraints;
- alignment and transfer granularity;
- mask modes, lane interpretation, repeat limits, and stride units;
- overlap/alias restrictions;
- pipeline classification;
- flag, wait, event, and barrier requirements;
- local-memory restrictions;
- tail and padding requirements;
- unsupported combinations and version-specific differences;
- page, section, table, or figure citation for every consequential constraint.

Prefer one atomic card for one compatibility scope. Split the card when two compiler versions or product families have materially different signatures or rules.

## Compatibility classification

| Document scope | Classification |
|---|---|
| Exact Ascend 310P and exact active CANN/CCE version | Candidate T2 / EXACT |
| Same generation with explicit compatibility proof | Candidate T4 / PROVEN_COMPATIBLE |
| Original Ascend 310, A2/A3, another product/generation, or unresolved product scope | T5 / CONCEPT_ONLY or UNKNOWN |
| Third-party/unverified document | T6 / UNKNOWN |

Only exact or proven-compatible evidence may contribute to `usable_for_codegen: true`. Compiler acceptance should still be obtained when feasible, especially for overloads, argument units, or behavior that the PDF leaves ambiguous.

## Normalization and licensing

Create an `OFFICIAL_REFERENCE` card for document scope and separate `API` or hardware cards for reusable facts. Store concise normalized facts and citations instead of reproducing whole pages. Record the PDF hash so future revisions can be detected.

## Conflict handling

If a PDF conflicts with current compiler behavior or a known-good current repository operator:

1. do not rewrite the stronger local card;
2. verify that product/version scopes really match;
3. create a conflict entry in `kb_ingestion_report.json`;
4. quarantine the unresolved candidate;
5. state the minimal compiler, build, or board experiment required to resolve it.
