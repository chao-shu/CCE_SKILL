# Operator Directory Ingestion

Use this mode for one or more existing CCE-C operator directories.

## Inventory

Identify and hash applicable:

- `.cce` device source;
- included headers and builtin declarations;
- C/C++/Python host, launch, registration, and oracle code;
- CMake/Make/shell build entry points and target flags;
- operator metadata and shape/dtype declarations;
- tests, expected outputs, tolerances, logs, build reports, accuracy reports, profiler output, and board records;
- repository remote, commit, dirty state, and generated-file boundaries.

Do not traverse `.git`, dependency caches, or unrelated build trees unless a required artifact is located there. Do not follow symlinks outside the supplied directory without explicit authorization.

## Establish what “correct” means

Classify each operator separately:

| Available evidence | Allowed conclusion |
|---|---|
| Source only or user assertion only | Candidate pattern; normally T6/PROVISIONAL |
| Exact current repository convention plus reproducible known-good build evidence | T1 project/API evidence within that environment |
| Current compiler accepts an isolated exact signature or the exact source | T0 compiler legality evidence for the tested form |
| Build PASS + accuracy PASS | Correct for the tested cases; not yet Golden |
| Build PASS + accuracy PASS + actual Ascend 310P board PASS | Eligible Golden Operator, normally T3 |
| Measured before/after profile with stable harness | Eligible performance case with narrow scope |

Never infer board execution from a binary, log filename, or the word “310” in a path. Preserve `NOT_RUN` when evidence is absent.

## Source analysis

For every nontrivial CCE-C construct, record:

- exact token and call site;
- declaration/header evidence when available;
- argument expressions and statically known types;
- GM/UB/L1/L0 address spaces involved;
- surrounding mask/repeat/stride setup;
- producing and consuming pipelines;
- flag/wait/barrier/event sequence;
- buffer offsets, allocation idioms, and live-range clues;
- core-index and quotient/remainder behavior;
- full and tail paths;
- build target and compiler flags that select the device generation.

Separate observed facts from interpretation. A call argument named `len` does not prove whether the unit is bytes, blocks, elements, or repeats.

## Cards to create

- One `API` card per exact symbol/signature/constraint set. Split cards when overloads or compiler generations differ materially.
- `PROJECT_CONVENTION` cards for canonical build, registration, launch, generated-file, and test behavior.
- A `GOLDEN_OPERATOR` candidate for each operator, promoted only when all Golden gates pass.
- `PATTERN` cards only with narrow applicability and source operator IDs. Prefer multiple independent examples before generalizing.
- `FAILURE` or `PERFORMANCE` cards only when corresponding diagnostics or measurements exist.

## Cross-checks

Before promotion:

1. match source target flags to Ascend 310P, not merely original Ascend 310;
2. reject accidental Ascend C/TIK/TBE material as CCE-C authority;
3. compare repeated interface use across operators;
4. compare source facts with exact-version documentation when available;
5. compile minimal probes or the canonical target when current execution is authorized and possible;
6. record unsupported shapes, dtypes, and compiler versions explicitly.

When an operator is generated code, preserve the generator and regeneration boundary. Do not teach the Agent to hand-edit generated output unless that is the verified repository convention.
