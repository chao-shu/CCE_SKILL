---
name: ascend310p-ccec-kb-ingestion
description: Independently bootstrap the Ascend 310P CCE-C knowledge base from supplied known-good operator directories and/or version-scoped interface-document PDFs. Invoke explicitly for initial or user-requested re-ingestion; never invoke from the operator orchestrator or use it for routine post-run knowledge updates.
metadata:
  compatibility: "opencode"
  target: "Ascend 310P"
  architecture: "DaVinci"
  backend: "CCE-C"
  stage: "knowledge ingestion"
  role: "offline bootstrap"
  invocation: "explicit"
---

# Mission

Convert supplied operator source directories and/or interface-document PDFs into traceable, version-aware knowledge cards for the existing Ascend 310P CCE-C workflow.

This Skill performs evidence ingestion. It does not assume that user-provided code, a PDF, or a successful parse is sufficient proof of CCE-C legality.

# Invocation boundary

This is an independent, explicitly invoked bootstrap workflow. Do not call it from `ascend310p-ccec-operator-orchestrator`, `ascend310p-ccec-kb-retrieval`, or any normal operator-development stage.

After an ingestion run completes, routine knowledge additions, promotions, corrections, failure capture, Golden Operator creation, and performance-case updates belong exclusively to `ascend310p-ccec-kb-curation`, using evidence produced by completed operator runs.

Run this Skill again only when the user explicitly supplies new operator directories/PDFs or requests a complete re-ingestion.

# Inputs

Accept one or both:

- `OPERATOR_DIRS`: existing operator directories containing `.cce` source and relevant build, registration, launch, test, log, or report files;
- `PDF_DOCS`: interface-document PDFs;
- `RUN_DIR`: `.operator-agent/runs/<run_id>/`;
- optional known target, CANN version, CCE/BiSheng version, source revision, and board/build/accuracy evidence.

If the target is not explicitly supplied, the requested target remains `Ascend310P / DaVinci / CCE-C`, but compatibility must still be proven from the inputs. Original Ascend 310 is a different product target and must not be silently accepted as equivalent.

# Mode routing

- Operator directories only: read [references/operator-directory-ingestion.md](references/operator-directory-ingestion.md).
- PDFs only: read [references/pdf-interface-ingestion.md](references/pdf-interface-ingestion.md).
- Both: read both references and use source/document agreement plus current compiler evidence to strengthen or reject candidate facts.
- Before writing cards, read [references/output-contract.md](references/output-contract.md).

# Preconditions and write boundary

1. Inventory every supplied input and record a stable path, size, SHA-256, and source revision when available. Prefer `scripts/inventory_inputs.py`.
2. Detect or record the exact SoC, CANN version, compiler version, backend, and repository revision when evidence is available.
3. Do not modify supplied operator source, build scripts, PDFs, or production code.
4. Write intermediate cards only under `RUN_DIR/kb_candidates/`.
5. Promote cards only into the matching `knowledge/` collection after the quality gates below pass.
6. Before changing any existing knowledge card, save its exact bytes and SHA-256 under `RUN_DIR/kb_prechange_snapshot/`; record newly created paths separately so this run can roll back only its own writes.

# Evidence rules

Preserve the workflow trust ladder:

- `T0`: current compiler acceptance, current build/disassembly, or equivalent direct local evidence;
- `T1`: current repository CCE-C code proven to work for the identified Ascend 310P environment;
- `T2`: official documentation matching the exact target and installed CANN/CCE version;
- `T3`: local Golden Operator with build, accuracy, and actual Ascend 310P board PASS;
- `T4`: same-generation official/generated material with explicit compatibility evidence;
- `T5`: other product/generation official material;
- `T6`: external material, unsupported inference, or unverified user-supplied content.

Rules:

- “Existing correct operator” is an ingestion hint, not a trust level. Derive trust from attached build, accuracy, board, revision, and environment evidence.
- A PDF establishes `T2` only when its product scope and CANN/CCE version match the active Ascend 310P environment.
- `T5/T6` evidence is concept-only and may not set `usable_for_codegen: true`.
- Source usage proves that a spelling or call pattern exists; it does not by itself prove parameter units, alignment, mask, repeat, stride, pipeline, event, or tail semantics.
- Prefer current compiler and current repository evidence when code and documentation disagree.

# Extraction outcomes

Generate only applicable card types:

- `API`: exact intrinsic, builtin, qualifier, attribute, or compiler syntax;
- `PROJECT_CONVENTION`: build, registration, launch, file layout, target flags, or testing convention;
- `GOLDEN_OPERATOR`: only after build + accuracy + Ascend 310P board PASS;
- `PATTERN`: narrowly scoped implementation pattern with explicit reuse boundaries;
- `FAILURE`: reproduced failure signature, root cause, and verified or provisional fix;
- `PERFORMANCE`: measured before/after case with profiler evidence and KEEP/REVERT;
- `OFFICIAL_REFERENCE`: normalized PDF scope and facts;
- hardware/local-document metadata where the existing knowledge layout requires it.

Do not generalize one operator into a universal hardware rule. When evidence supports only one dtype, shape, compiler, or instruction form, keep that limitation in the card.

# Candidate and conflict workflow

Read `contracts/KB_DEDUPLICATION.md`. Run the overlap scan for raw candidates against the existing KB and record SKIP/MERGE/ADD/QUARANTINE for every candidate. Resolve repeated facts into canonical cards, then assemble final intended writes in `RUN_DIR/kb_promotion/`; use that directory for candidate lint/index/query below. Retain raw skipped/conflicting candidates as run evidence.

1. Run `python tools/kb_lint.py --knowledge knowledge` before mutation to establish a clean baseline, then build the input inventory and evidence ledger. If the existing KB is already invalid, report the pre-existing errors and do not promote new trusted cards until they are resolved.
2. Extract atomic facts with exact source locations.
3. Create or update candidate Markdown cards using `knowledge/_templates/`.
4. Compare candidates against existing cards by `id`, symbol, target, compiler version, and semantic constraint.
5. For disagreements, preserve both claims in the ingestion report and keep the unresolved candidate under `RUN_DIR/kb_candidates/quarantine/`; never overwrite the stronger card silently.
6. Validate the final intended writes with `python tools/kb_lint.py --knowledge <RUN_DIR>/kb_promotion`. Candidate lint must PASS before any promotion.
7. Build and inspect a candidate-only index with `python tools/kb_index.py --knowledge <RUN_DIR>/kb_promotion --db <RUN_DIR>/kb_promotion.sqlite`; run representative strict target/API queries against that database.
8. Promote only validated cards whose metadata, provenance, compatibility, and destination are valid. Validated unresolved cards may be copied to `knowledge/quarantine/`, never to a trusted collection.
9. Update `knowledge/index.md` with promoted card IDs and paths.
10. Validate the resulting complete KB with `python tools/kb_lint.py --knowledge knowledge`, rebuild the canonical index with `python tools/kb_index.py --knowledge knowledge --db .operator-agent/kb.sqlite`, and run strict post-promotion sample queries.
11. If any post-promotion validation fails, restore only paths written by this run from `RUN_DIR/kb_prechange_snapshot/`, remove only newly created paths recorded by this run, preserve the candidates and diagnostics in `RUN_DIR`, and return `FAIL`. Never leave a partially promoted trusted KB.

Snapshot index.md before modification. After rollback rebuild the canonical SQLite index from the restored Markdown and rerun lint/query, so retrieval cannot consume a rejected promotion.

# Promotion gates

An API card may set `usable_for_codegen: true` only when all applicable facts needed for its intended use are supported:

- exact symbol/signature or syntax;
- exact target and compiler/CANN scope;
- parameter units and ranges;
- address-space constraints;
- dtype support;
- alignment, mask, repeat, stride, and overlap constraints as applicable;
- pipeline and synchronization semantics as applicable;
- concrete provenance and verification evidence.

If any required fact is missing, keep the card `PROVISIONAL`, set `usable_for_codegen: false`, and record the exact verification needed.

# PDF and licensing boundary

Store normalized facts, short necessary excerpts, page/section citations, hashes, and local document locations. Do not copy complete proprietary documents into the repository unless the user has explicitly requested it and their licensing rules permit it.

# Output

Write `RUN_DIR/kb_ingestion_report.json` according to [references/output-contract.md](references/output-contract.md), including:

- mode and target fingerprint;
- complete input inventory;
- created, updated, promoted, quarantined, skipped, and conflicting cards;
- trust/compatibility reasoning;
- validation commands and results;
- blockers and next verification actions.

Also write `RUN_DIR/stage_reports/kb_ingestion.json` according to `contracts/STAGE_REPORT.md` and validate it with `tools/validate_stage_report.py`. `PASS` means candidate validation and complete-KB post-promotion validation completed honestly; it does not mean every candidate became code-generation authority.

# Handoff to the operator workflow

On completion, freeze `kb_ingestion_report.json` as the bootstrap record. The operator orchestrator may consume the resulting validated KB through `ascend310p-ccec-kb-retrieval`, but it must not call this Skill.

All knowledge learned from later build, accuracy, board, failure, profiling, optimization, regression, or release runs must be handled by `ascend310p-ccec-kb-curation`. This Skill must not pre-claim or later maintain those results.
