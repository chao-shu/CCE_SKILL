#!/usr/bin/env python3
"""Create a read-only, hash-based inventory of operator directories and PDFs."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any


SKIP_DIRS = {
    ".git",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".operator-agent",
    "node_modules",
}


def sha256(path: Path, max_bytes: int) -> str | None:
    if path.stat().st_size > max_bytes:
        return None
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def category(path: Path) -> str:
    name = path.name.lower()
    suffix = path.suffix.lower()
    if suffix == ".cce":
        return "cce_source"
    if suffix in {".h", ".hpp", ".hh"}:
        return "header"
    if suffix in {".c", ".cc", ".cpp", ".py"}:
        return "host_or_reference_source"
    if suffix in {".sh", ".cmake", ".mk"} or name in {"cmakelists.txt", "makefile"}:
        return "build"
    if "test" in name or "accuracy" in name:
        return "test_or_accuracy"
    if "profile" in name or "perf" in name or "benchmark" in name:
        return "performance"
    if suffix in {".json", ".yaml", ".yml"}:
        return "metadata_or_report"
    if suffix in {".md", ".txt", ".log"}:
        return "documentation_or_log"
    return "other"


def git_metadata(directory: Path) -> dict[str, Any]:
    def run(*args: str) -> str | None:
        try:
            result = subprocess.run(
                ["git", "-C", str(directory), *args],
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True,
                timeout=10,
            )
            return result.stdout.strip()
        except (OSError, subprocess.SubprocessError):
            return None

    root = run("rev-parse", "--show-toplevel")
    if not root:
        return {"root": None, "commit": None, "dirty": None}
    status = run("status", "--porcelain")
    return {
        "root": root,
        "commit": run("rev-parse", "HEAD"),
        "dirty": None if status is None else bool(status),
    }


def inventory_directory(path: Path, max_files: int, max_hash_bytes: int) -> dict[str, Any]:
    root = path.resolve()
    files: list[dict[str, Any]] = []
    truncated = False
    stop = False
    for current, dirnames, filenames in os.walk(root, topdown=True, followlinks=False):
        current_path = Path(current)
        retained_dirs: list[str] = []
        for name in sorted(dirnames):
            candidate = current_path / name
            if name in SKIP_DIRS:
                continue
            if candidate.is_symlink():
                files.append({
                    "path": str(candidate.relative_to(root)),
                    "kind": "symlink",
                    "target": str(candidate.readlink()),
                })
            else:
                retained_dirs.append(name)
            if len(files) >= max_files:
                truncated = True
                stop = True
                break
        dirnames[:] = retained_dirs
        if stop:
            break

        for name in sorted(filenames):
            candidate = current_path / name
            relative = candidate.relative_to(root)
            if candidate.is_symlink():
                files.append({
                    "path": str(relative),
                    "kind": "symlink",
                    "target": str(candidate.readlink()),
                })
            elif candidate.is_file():
                files.append({
                    "path": str(relative),
                    "kind": category(candidate),
                    "size_bytes": candidate.stat().st_size,
                    "sha256": sha256(candidate, max_hash_bytes),
                })
            if len(files) >= max_files:
                truncated = True
                stop = True
                break
        if stop:
            break
    return {
        "kind": "operator_dir",
        "path": str(root),
        "git": git_metadata(root),
        "file_count": len(files),
        "truncated": truncated,
        "files": files,
    }


def inventory_pdf(path: Path, max_hash_bytes: int) -> dict[str, Any]:
    resolved = path.resolve()
    with resolved.open("rb") as stream:
        header = stream.read(5)
    return {
        "kind": "pdf",
        "path": str(resolved),
        "size_bytes": resolved.stat().st_size,
        "sha256": sha256(resolved, max_hash_bytes),
        "pdf_header_valid": header == b"%PDF-",
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--operator-dir", action="append", default=[])
    parser.add_argument("--pdf", action="append", default=[])
    parser.add_argument("--output", default="-")
    parser.add_argument("--max-files", type=int, default=10000)
    parser.add_argument("--max-hash-mib", type=int, default=256)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if not args.operator_dir and not args.pdf:
        raise SystemExit("Provide at least one --operator-dir or --pdf")
    if args.max_files < 1 or args.max_hash_mib < 1:
        raise SystemExit("--max-files and --max-hash-mib must be positive")

    max_hash_bytes = args.max_hash_mib * 1024 * 1024
    inputs: list[dict[str, Any]] = []
    errors: list[str] = []

    for raw in args.operator_dir:
        path = Path(raw)
        if not path.is_dir():
            errors.append(f"operator directory not found: {raw}")
            continue
        inputs.append(inventory_directory(path, args.max_files, max_hash_bytes))

    for raw in args.pdf:
        path = Path(raw)
        if not path.is_file():
            errors.append(f"PDF not found: {raw}")
            continue
        inputs.append(inventory_pdf(path, max_hash_bytes))

    result = {
        "schema_version": 1,
        "created_at": dt.datetime.now(dt.timezone.utc).isoformat(),
        "inputs": inputs,
        "errors": errors,
    }
    payload = json.dumps(result, indent=2, ensure_ascii=False) + "\n"
    if args.output == "-":
        sys.stdout.write(payload)
    else:
        output = Path(args.output)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(payload, encoding="utf-8")
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
