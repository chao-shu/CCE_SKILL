---
name: ascend310p-ccec-baseline-codegen
description: Implement an approved Ascend 310P DaVinci design as complete correctness-first CCE-C `.cce` code using only locally or exactly verified compiler intrinsics, address spaces, synchronization rules and repository integration conventions.
metadata:
  compatibility: "opencode"
  target: "Ascend 310P"
  architecture: "DaVinci"
  backend: "CCE-C"
  stage: "baseline code generation"
---

# Mission

Generate the simplest complete **CCE-C** baseline matching `semantic_spec.json` and `design.json`.

# Hard backend rule

Production kernel source must remain CCE-C according to this repository's conventions.

Forbidden substitutions unless explicitly requested by the user:

- `AscendC::` API rewrite;
- `TPipe/TQue/TBuf` architecture;
- TIK DSL source as final deliverable;
- TBE DSL source as final deliverable.

# API legality

Before emitting each unfamiliar keyword/intrinsic/signature:

1. check `kb_evidence.json` for `usable_for_codegen=true`;
2. otherwise inspect current compiler/repository evidence;
3. if legality cannot be proven, do not emit it.

Never synthesize an intrinsic signature from original Ascend 310, A2/A3, or another product's page and assume Ascend 310P compatibility.

# Kernel implementation

Implement complete repository-required pieces. The device code may use verified conventions such as:

- `.cce` file;
- verified kernel-entry attributes;
- verified GM/UB/etc. qualifiers;
- verified intrinsic calls;
- verified block index;
- explicit local-memory addresses/offsets;
- explicit data movement;
- explicit vector/cube operations;
- explicit synchronization/barriers.

These are examples of categories, not permission to invent specific syntax.

# Memory safety

For every buffer access prove:

- allocated local range contains the access;
- live buffers do not overlap illegally;
- GM address range is valid;
- aligned transfer does not touch invalid memory;
- tail output does not overwrite beyond semantic output.

# Synchronization safety

Implement exactly the dependency plan approved in `design.json`.

Do not add/remove `set_flag`, `wait_flag`, `pipe_barrier`, event IDs or equivalent primitives casually. Any deviation from design must update evidence/design first.

# Baseline restrictions

Avoid speculative:

- double buffer;
- manual software pipeline unrolling;
- maximal event-ID reuse;
- aggressive UB aliasing;
- shape-specific specialization;
- complex Cube/Vector overlap.

unless required by the approved baseline design.

# Completeness

No TODO, pseudocode, placeholder offsets, placeholder repeat counts, guessed masks, guessed transfer blocks or missing tail path.

# Output

Write `RUN_DIR/code_report.json` containing modified files, used intrinsics with evidence IDs, assumptions and any remaining unverified item.

Do not claim build success until the build stage proves it.

Also write `RUN_DIR/stage_reports/baseline_codegen.json` according to `contracts/STAGE_REPORT.md` and validate it with `tools/validate_stage_report.py`.
