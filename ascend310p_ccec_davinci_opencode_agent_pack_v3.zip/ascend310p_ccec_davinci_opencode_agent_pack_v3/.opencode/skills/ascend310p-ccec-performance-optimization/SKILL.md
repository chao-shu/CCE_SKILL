---
name: ascend310p-ccec-performance-optimization
description: Optimize verified Ascend 310P CCE-C kernels through profiler-driven hypotheses involving DaVinci DMA, UB reuse, vector mask/repeat/stride, pipeline overlap, explicit events, double buffering, multicore balance and Cube/Vector scheduling, with mandatory build/accuracy/profile KEEP-or-REVERT gates.
metadata:
  compatibility: "opencode"
  target: "Ascend 310P"
  backend: "CCE-C"
  stage: "performance optimization"
---

# Preconditions

- BUILD PASS
- ACCURACY PASS
- baseline profiling stage PASS, validated against the accepted revision

# Mission

Improve measured performance without changing semantics.

# One-hypothesis rule

Normally change one major performance variable per iteration.

Candidate dimensions include only when supported by evidence:

- active core count / quotient-remainder strategy;
- tile size;
- DMA burst aggregation;
- source/destination stride pattern;
- eliminating redundant GM round trips;
- UB layout/lifetime reuse;
- vector repeat count;
- vector mask strategy;
- vector block/repeat stride;
- scalar-loop replacement with vector intrinsic;
- reducing unnecessary barriers;
- tighter event placement;
- safe event reuse;
- double buffering/ping-pong UB;
- MTE↔Vector overlap;
- MTE↔Cube/Vector overlap;
- Cube tile/format schedule;
- fusing local intermediate stages.

# Double-buffer requirement

Double buffering is not a checkbox. Before implementation prove:

- two non-overlapping local buffers;
- producer/consumer state for each buffer;
- event/flag ownership;
- safe event reuse;
- no overwrite while previous compute/store is live;
- tail behavior.

# Synchronization optimization

Removing a wait/barrier requires a dependency proof. Adding a wait/barrier requires a hazard justification.

# Every iteration

Read and follow `contracts/OPTIMIZATION_EVIDENCE.md`. Freeze the accepted code/design/report set before edits with `tools/optimization_checkpoint.py`; preserve each candidate separately. REVERT restores code, design and their verification artifacts together, followed by hash/report revalidation. The controller dispatches independent build/accuracy/profiling stages and owns accepted-revision state; the optimizer cannot self-certify them.

Record:

```text
Observed bottleneck
Hypothesis
Code change
Expected effect
BUILD result
ACCURACY result
Measured before
Measured after
Decision: KEEP | REVERT
```

If build/accuracy fails, REVERT before trying another optimization.

If improvement is noise-level or critical shapes regress materially, REVERT.

# Output

Append `RUN_DIR/optimization_log.jsonl` and keep the repository on the last verified accepted revision.

Also write `RUN_DIR/stage_reports/performance_optimization.json` according to `contracts/STAGE_REPORT.md` and validate it with `tools/validate_stage_report.py` after the loop reaches its final accepted or blocked state.
