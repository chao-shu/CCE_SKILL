---
name: ascend310p-ccec-build-debug
description: Compile Ascend 310P CCE-C code with the repository's actual CCE/BiSheng flow, classify the earliest meaningful compiler/link/integration error, and make minimal evidence-based fixes without migrating the kernel to another backend.
metadata:
  compatibility: "opencode"
  target: "Ascend 310P"
  backend: "CCE-C"
  stage: "build debug"
---

# Mission

Prove source legality using the real CCE toolchain.

# Build rule

Use the repository's canonical command and target flags discovered by environment/repo-context stages. Never invent compiler flags from another CANN version.

Prefer clean/reproducible build where practical.

# First-root-cause discipline

On failure:

1. capture full diagnostics;
2. identify earliest meaningful error;
3. classify root cause;
4. repair the minimum source/build region;
5. rebuild;
6. only then address the next root cause.

# Failure classes

Use applicable:

- `CCE_INTRINSIC_NOT_AVAILABLE`
- `CCE_INTRINSIC_SIGNATURE`
- `ADDRESS_SPACE_TYPE_ERROR`
- `VECTOR_MASK_ERROR`
- `REPEAT_STRIDE_CONSTRAINT`
- `DMA_PARAMETER_ERROR`
- `EVENT_PIPELINE_ERROR`
- `LOCAL_MEMORY_ERROR`
- `CUBE_FORMAT_ERROR`
- `KERNEL_ATTRIBUTE_ERROR`
- `TARGET_ARCH_ERROR`
- `LINK_REGISTRATION_ERROR`
- `BUILD_SYSTEM_ERROR`
- `UNKNOWN`

# Anti-pattern

Do not “fix” an unavailable CCE-C intrinsic by rewriting the operator in Ascend C/TIK/TBE.

# Output

Write `RUN_DIR/build_report.json` with command, return code, diagnostics summary, root-cause history, modifications and final `PASS|FAIL|BLOCKED`.

Accuracy is prohibited until build is PASS.

Also write `RUN_DIR/stage_reports/build.json` according to `contracts/STAGE_REPORT.md` and validate it with `tools/validate_stage_report.py`.
