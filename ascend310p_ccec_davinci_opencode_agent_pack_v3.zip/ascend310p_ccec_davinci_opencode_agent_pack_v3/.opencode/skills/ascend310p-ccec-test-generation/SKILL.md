---
name: ascend310p-ccec-test-generation
description: Build deterministic semantic and hardware-boundary test matrices for an Ascend 310P CCE-C operator without inventing unverified DaVinci boundary constants.
metadata:
  compatibility: "opencode"
  target: "Ascend 310P"
  stage: "test generation"
---

# Mission

Create tests capable of exposing semantic, multicore, DMA, vector-mask, tiling and precision defects.

# Required case categories

Include applicable:

- smallest legal tensors;
- sizes around verified vector-mask/repeat boundaries;
- sizes around verified DMA/alignment boundaries;
- below/exact/above tile boundaries;
- below/exact/above core-partition boundaries;
- uneven core work distribution;
- tail lengths of 1 and other awkward small lengths;
- representative production shapes;
- zero/one/negative/mixed-sign/random/extreme values;
- domain boundaries, NaN/Inf where relevant;
- every supported dtype.

Do not guess a hardware constant. If a boundary depends on later DaVinci design, express the case symbolically and let the accuracy stage instantiate it from verified `design.json`.

# Oracle

Python reference output is the default oracle.

# Output

Write `RUN_DIR/test_plan.json` according to `contracts/TEST_PLAN.md`.

Also write `RUN_DIR/stage_reports/test_generation.json` according to `contracts/STAGE_REPORT.md` and validate it with `tools/validate_stage_report.py`.
