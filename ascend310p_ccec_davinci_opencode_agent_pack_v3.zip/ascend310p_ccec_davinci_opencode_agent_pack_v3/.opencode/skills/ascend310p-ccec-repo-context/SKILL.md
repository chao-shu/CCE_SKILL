---
name: ascend310p-ccec-repo-context
description: Analyze the repository's existing Ascend 310P CCE-C source layout, build/registration/invocation conventions, verified kernels, generated boundaries and test infrastructure without changing production code.
metadata:
  compatibility: "opencode"
  target: "Ascend 310P"
  backend: "CCE-C"
  stage: "repository context"
---

# Mission

Extract the repository-specific contract before implementation.

# Inspect

Find and summarize:

- `.cce` kernels and naming conventions;
- `__global__` / `__aicore__` entry conventions actually used;
- address-space qualifiers actually used (`__gm__`, `__ubuf__`, etc.);
- intrinsic families already compiling on Ascend 310P;
- block/core index access patterns;
- UB allocation idioms such as `get_imm` if present;
- vector mask/repeat/stride idioms;
- data movement idioms;
- `set_flag`/`wait_flag`/barrier/event patterns;
- Cube/L1/L0 patterns if the project contains them;
- operator registration, metadata and launch glue;
- canonical build commands;
- generated files that must not be hand-edited;
- existing Python or C++ test harnesses;
- existing board execution/profiling scripts;
- nearest working operators by semantic family.

# Required backend verdict

The project target for this workflow is `CCE-C`. If the repository lacks direct CCE-C infrastructure, report that clearly; do not silently choose Ascend C/TIK/TBE.

# Output

Write `RUN_DIR/repo_context.json` with paths, conventions, golden candidates, canonical commands and modification boundaries.

Do not modify production source.

Also write `RUN_DIR/stage_reports/repo_context.json` according to `contracts/STAGE_REPORT.md` and validate it with `tools/validate_stage_report.py`.
