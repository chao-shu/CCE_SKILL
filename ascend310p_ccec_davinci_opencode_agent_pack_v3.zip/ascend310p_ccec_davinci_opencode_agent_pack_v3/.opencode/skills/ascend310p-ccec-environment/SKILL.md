---
name: ascend310p-ccec-environment
description: Fingerprint the actual Ascend 310P CCE-C development environment, CANN/CCE/BiSheng compiler, SoC, board visibility, build/runtime/profile capabilities and evidence roots before any CCE-C implementation decision.
metadata:
  compatibility: "opencode"
  target: "Ascend 310P"
  architecture: "DaVinci"
  backend: "CCE-C"
  stage: "environment"
---

# Mission

Establish environmental facts for **Ascend 310P + CCE-C**. Never infer them from model memory.

# Required investigation

Inspect read-only where available:

1. OS and host architecture;
2. CANN/toolkit installation roots and version;
3. `npu-smi info` and actual product/SOC visibility;
4. repository environment setup scripts;
5. CCE/BiSheng compiler commands such as repository wrappers, `ccec`, `bisheng`, or equivalent;
6. compiler `--version` output when safe;
7. `.cce` source locations;
8. compile flags and target-architecture flags from working build scripts;
9. installed CCE intrinsic headers/builtin declarations/reference files if exposed;
10. existing generated CCE-C artifacts if this repository/toolchain exposes them;
11. runtime/ACL launch mechanism used by the project;
12. profiler availability (`msprof` or project equivalent);
13. whether local compilation, board execution and profiling are actually possible.

Do **not** assume modern `msopgen`, `TPipe`, `TQue`, `AscendC::` infrastructure applies.

# Version compatibility warning

Public CCE Intrinsic documentation may target original Ascend 310, A2/A3, or another product. Record it as non-authoritative for Ascend 310P unless exact compatibility is proven by the current compiler/environment.

# Required output

Write `RUN_DIR/environment.json` including:

```json
{
  "stage": "environment",
  "status": "PASS",
  "target": {
    "requested": "Ascend310P",
    "architecture": "DaVinci",
    "backend": "CCE-C",
    "detected_soc": null,
    "device_visible": false
  },
  "cann": {"version": null, "roots": [], "env_scripts": []},
  "cce": {
    "compiler": null,
    "compiler_version": null,
    "toolchain_roots": [],
    "known_target_flags": [],
    "intrinsic_evidence_roots": []
  },
  "capabilities": {"compile": false, "board_execute": false, "profile": false},
  "commands_executed": [],
  "warnings": [],
  "blockers": []
}
```

PASS means the environment is sufficiently fingerprinted for honest downstream decisions; it does not require a visible board.

Also write `RUN_DIR/stage_reports/environment.json` according to `contracts/STAGE_REPORT.md` and validate it with `tools/validate_stage_report.py`.
