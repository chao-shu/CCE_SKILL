---
name: ascend310p-ccec-kb-retrieval
description: Retrieve trust-ranked, version-compatible CCE-C/DaVinci evidence for Ascend 310P, prioritizing current compiler and locally verified kernels while preventing contamination from newer SoC CCE Intrinsic examples.
metadata:
  compatibility: "opencode"
  target: "Ascend 310P"
  backend: "CCE-C"
  stage: "knowledge retrieval"
---

# Mission

Retrieve only evidence relevant to the actual Ascend 310P CCE-C environment.

Inputs:

- `environment.json`
- `repo_context.json`
- `semantic_spec.json`

# Mandatory hard filters

Before semantic similarity, filter/rank by:

1. exact target `Ascend310P`;
2. exact or proven-compatible CANN/CCE compiler generation;
3. backend `cce-c`;
4. DaVinci generation/product compatibility;
5. operator family;
6. dtype/layout when relevant.

Use strict dimension matching for production evidence. A typical API query includes the detected SoC, architecture, CANN/compiler, backend, `--status VERIFIED`, and `--usable-for-codegen true`. Such a query must not use `--include-unknown-dimensions`.

The query tool requires all five concrete flags for code generation: `--soc`, `--architecture`, `--cann`, `--compiler`, `--backend`. Unknown versions or missing flags fail closed. Use exact values from environment.json; never fill a missing version with a guessed value to satisfy the parser.

If strict retrieval is insufficient, a separate conceptual search may use `--include-unknown-dimensions`. Keep those results in a clearly marked hypothesis section with `usable_for_codegen=false`; they may guide further compiler/document investigation but may not establish an API, signature or hardware constraint.

# Trust ladder

- T0: current local compiler/build/disassembly evidence;
- T1: current repository code that compiles/runs on this Ascend 310P setup;
- T2: exact-version official Ascend 310P CCE/CCE-C documentation;
- T3: board-verified local Golden Operator;
- T4: same-generation official example or generated CCE-C with compatibility evidence;
- T5: newer/different SoC official CCE Intrinsic documentation;
- T6: external material or model memory.

T5/T6 are **never** API-legality proof.

# Retrieve evidence for

- kernel declaration/entry conventions;
- address-space keywords;
- data movement intrinsic signatures and units;
- Vector/Cube instruction signatures;
- vector mask/repeat/stride semantics;
- pipeline type for each intrinsic;
- event/barrier rules;
- UB/L1/L0 allocation and alignment constraints;
- multicore/block index mechanism;
- datatype support;
- known compiler bugs/failures;
- similar verified kernels;
- measured performance cases.

# Output

Write `RUN_DIR/kb_evidence.json` following `contracts/KB_EVIDENCE.md`.

Every API/intrinsic intended for code generation must have `usable_for_codegen=true` and a concrete provenance path.

Also write `RUN_DIR/stage_reports/kb_retrieval.json` according to `contracts/STAGE_REPORT.md` and validate it with `tools/validate_stage_report.py`.
