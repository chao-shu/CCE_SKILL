---
name: ascend310p-ccec-kb-curation
description: Promote verified Ascend 310P CCE-C compiler/API, Golden Operator, DaVinci pipeline, failure and measured performance knowledge into provenance-rich Markdown cards while quarantining unverified cross-generation claims.
metadata:
  compatibility: "opencode"
  target: "Ascend 310P"
  backend: "CCE-C"
  stage: "knowledge curation"
---

# Mission

Turn completed engineering evidence into durable local knowledge without poisoning the KB.

After the independent `ascend310p-ccec-kb-ingestion` bootstrap has completed, this Skill is the sole workflow owner for routine knowledge creation, promotion, correction, failure capture, Golden Operator updates and performance-case updates. Do not invoke or delegate back to the ingestion Skill.

# Inputs

Read the completed run's `release_report.json`, applicable stage reports under `RUN_DIR/stage_reports/`, referenced build/accuracy/board/profile/regression artifacts, and the exact source revision. Do not promote a claim from an unreferenced transcript or unsupported summary.

# Card types

- `API`
- `GOLDEN_OPERATOR`
- `PATTERN`
- `FAILURE`
- `PERFORMANCE`
- `PROJECT_CONVENTION`
- `OFFICIAL_REFERENCE`

# Promotion rules

## API card

May become `VERIFIED` when at least one strong current-environment proof exists, preferably:

- current CCE compiler accepts the exact signature for the target;
- and/or current repository build proves it;
- plus board evidence where runtime behavior matters.

## Golden Operator

Requires at least:

- clean build PASS;
- accuracy PASS;
- Ascend 310P board PASS.

Performance need not be optimal.

## Performance card

Must record exact:

- target/product;
- CANN/CCE compiler version;
- operator/shape/dtype;
- source revision;
- before/after latency;
- profiler evidence;
- optimization change;
- KEEP/REVERT decision.

Never promote “double buffer is faster” as a universal rule.

# Cross-generation quarantine

Any finding sourced only from original Ascend 310, A2/A3, another product/generation, an external repo, or model memory belongs in `quarantine` until current Ascend 310P evidence confirms it.

# Transactional curation workflow

1. Create proposed cards only under `RUN_DIR/kb_curation_candidates/` using `knowledge/_templates/`.
2. Compare each candidate with existing cards by ID, target, compiler/CANN version, signature, evidence and scope. Preserve conflicts; do not silently replace stronger evidence.
3. Run `python tools/kb_lint.py --knowledge <RUN_DIR>/kb_curation_candidates`. Candidate lint must PASS before any knowledge write.
4. Run `python tools/kb_index.py --knowledge <RUN_DIR>/kb_curation_candidates --db <RUN_DIR>/kb_curation_candidates.sqlite` and run strict representative queries against that candidate-only database.
5. Before changing an existing knowledge card, save its exact bytes and SHA-256 under `RUN_DIR/kb_curation_prechange_snapshot/`; record every newly created path.
6. Promote valid cards to the matching `knowledge/` collection and update `knowledge/index.md`.
7. Run `python tools/kb_lint.py --knowledge knowledge`, rebuild the canonical index with `python tools/kb_index.py --knowledge knowledge --db .operator-agent/kb.sqlite`, and run strict post-write sample queries.
8. If post-write validation fails, restore only files changed by this curation run and remove only its recorded new files. Preserve candidates and diagnostics in `RUN_DIR`; return `FAIL` rather than leaving a partially updated KB.

For a terminal `FAIL` or `BLOCKED` operator run, curate only facts already supported by the available evidence. Failure cards and narrowly scoped corrections are allowed; do not create a Golden Operator, performance claim, board claim, or code-generation authority whose own gates did not pass.

# Output

Create/update validated Markdown cards under `knowledge/`, update `knowledge/index.md`, and write `RUN_DIR/kb_curation_report.json` with candidates, promoted/quarantined/skipped cards, conflicts, validation results, rollback status and source evidence IDs.

Write `RUN_DIR/stage_reports/kb_curation.json` according to `contracts/STAGE_REPORT.md` and validate it with `tools/validate_stage_report.py`.
