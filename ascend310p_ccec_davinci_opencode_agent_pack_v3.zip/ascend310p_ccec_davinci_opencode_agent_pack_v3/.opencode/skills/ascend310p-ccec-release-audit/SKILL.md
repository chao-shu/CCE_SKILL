---
name: ascend310p-ccec-release-audit
description: Audit all Ascend 310P CCE-C workflow evidence, final diff, build/accuracy/board/performance/regression results, API provenance and unsupported cases to issue a fail-closed release verdict without modifying production code.
metadata:
  compatibility: "opencode"
  target: "Ascend 310P"
  backend: "CCE-C"
  stage: "release audit"
---

# Mission

Issue the final truthfully scoped verdict.

Revalidate the consumed stage reports using `tools/validate_stage_report.py`. Check that the final source/design matches the accepted optimization checkpoint and its evidence under `contracts/OPTIMIZATION_EVIDENCE.md`; do not mix restored source with rejected-candidate reports. Hash validity is necessary but does not prove a log supports the claim: inspect the command, target, exit status and measured outcomes.

Verify:

- target is Ascend 310P;
- final backend is CCE-C;
- no accidental Ascend C/TIK/TBE migration occurred;
- every nontrivial intrinsic/signature used has acceptable evidence;
- source diff matches approved design;
- BUILD status;
- ACCURACY status;
- BOARD status;
- PERFORMANCE status;
- REGRESSION status;
- unsupported dtype/shape/domain list;
- unresolved assumptions.

If board execution did not occur, `BOARD=NOT_RUN` and wording must not claim hardware verification.

If performance profiling did not occur, do not claim the kernel is optimized merely because the code uses double buffering or vector intrinsics.

This stage also performs terminal closeout. When an upstream stage ended in genuine `FAIL` or `BLOCKED`, mark every unexecuted downstream gate `NOT_RUN`, set `FINAL` truthfully to `FAIL` or `BLOCKED`, and preserve the upstream failure evidence. Running release audit in this mode does not imply release approval.

Write `RUN_DIR/release_report.json` according to `contracts/RELEASE_REPORT.md`.

Write `RUN_DIR/stage_reports/release_audit.json` according to `contracts/STAGE_REPORT.md` and validate it with `tools/validate_stage_report.py`.
