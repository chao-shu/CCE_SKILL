---
name: ascend310p-ccec-regression
description: Run final independent clean-build, semantic, boundary, board and performance regression for an Ascend 310P CCE-C operator, with special coverage of DMA/vector/core/event tails and no production-code edits to force success.
metadata:
  compatibility: "opencode"
  target: "Ascend 310P"
  backend: "CCE-C"
  stage: "regression"
---

# Mission

Independently verify the final accepted CCE-C implementation.

Run applicable:

- clean CCE build;
- full dtype/shape matrix;
- core remainder boundaries;
- tile boundaries;
- DMA alignment/tail boundaries;
- vector mask/repeat boundaries;
- UB live-range stress shapes;
- Cube boundaries if applicable;
- board execution;
- performance regression against baseline/accepted target.

Do not edit production code in this stage. Return failures to the orchestrator.

Write `RUN_DIR/regression_report.json`.

Also write `RUN_DIR/stage_reports/regression.json` according to `contracts/STAGE_REPORT.md` and validate it with `tools/validate_stage_report.py`.
