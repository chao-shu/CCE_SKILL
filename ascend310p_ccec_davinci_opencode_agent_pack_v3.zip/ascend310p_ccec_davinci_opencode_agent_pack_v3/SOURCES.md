# Public Reference Bootstrap

These references are **bootstrap/context only**. API legality for the user's Ascend 310P must ultimately be established by the installed CCE toolchain, the repository's working Ascend 310P code, and documentation matching that exact product and environment.

## CCE-C / CCE concepts

- Huawei/MindSpore glossary: CCE is hardware-architecture-oriented operator development; CCE-C is C code developed by CCE; DaVinci is Huawei's chip architecture.
  - https://www.mindspore.cn/docs/programming_guide/en/r1.6/design/glossary.html

- Huawei CANN TIK documentation: TIK DSL is a higher-level abstraction that is compiled into CCE-C, then CCE compiler produces executable code.
  - https://www.hiascend.com/document/detail/en/canncommercial/800/opdevg/tbeaicpudevg/atlasopdev_10_0047.html

## CCE compiler / `.cce` examples

- BiSheng compiler quick start contains `.cce`, `__global__`, `__aicore__`, `__gm__` examples and kernel launch concepts.
  - https://www.hiascend.com/document/detail/zh/canncommercial/80RC2/developmentguide/opdevg/BishengCompiler/atlas_bisheng_10_0002.html

## CCE Intrinsic programming concepts

- CCE Intrinsic Vector example demonstrates direct UB allocation, GM↔UB movement, vector instruction, explicit flag/wait synchronization and barriers.
  - https://www.hiascend.com/document/detail/zh/CANNCommunityEdition/83RC1/opdevg/cceintrinsicguide/cceprogram_0025.html

- `copy_gm_to_ubuf` CCE Intrinsic reference illustrates direct GM→UB movement and PIPE_MTE2 classification.
  - https://www.hiascend.com/document/detail/zh/canncommercial/850/API/cceintrinsicapi/cceapi_0068.html

## Critical compatibility warning

Public CCE Intrinsic pages whose support matrix does not explicitly cover the active Ascend 310P and CANN/CCE version are useful only for understanding the programming model. Original Ascend 310, A2/A3, and other-product pages are **not authoritative Ascend 310P compatibility evidence** without local proof.

The workflow must verify every intrinsic/signature/constraint against the user's actual CANN/CCE version and/or locally working 310 kernels.
