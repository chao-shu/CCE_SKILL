# Package Manifest

Version: **3.1.0**
Target: **Ascend 310P / DaVinci / CCE-C**

Files: **62**

## Contents

- `.gitignore` — 121 bytes — `8b33861cb6ddd70b…`
- `.opencode/skills/ascend310p-ccec-accuracy-validation/SKILL.md` — 1950 bytes — `6b698fc1ec206f12…`
- `.opencode/skills/ascend310p-ccec-baseline-codegen/SKILL.md` — 3043 bytes — `675c0560b3c91a3e…`
- `.opencode/skills/ascend310p-ccec-build-debug/SKILL.md` — 1752 bytes — `3d9ad9a3e213bf4a…`
- `.opencode/skills/ascend310p-ccec-davinci-design/SKILL.md` — 5198 bytes — `ee5859f016e11c9b…`
- `.opencode/skills/ascend310p-ccec-environment/SKILL.md` — 2608 bytes — `f9a5f9877f040867…`
- `.opencode/skills/ascend310p-ccec-kb-curation/SKILL.md` — 4203 bytes — `1a3cfd8353a4e9ab…`
- `.opencode/skills/ascend310p-ccec-kb-ingestion/SKILL.md` — 9573 bytes — `06492d13c29cf661…`
- `.opencode/skills/ascend310p-ccec-kb-ingestion/references/operator-directory-ingestion.md` — 3596 bytes — `9dc30f03ddc19e87…`
- `.opencode/skills/ascend310p-ccec-kb-ingestion/references/output-contract.md` — 3150 bytes — `e6f01d0a11f726b9…`
- `.opencode/skills/ascend310p-ccec-kb-ingestion/references/pdf-interface-ingestion.md` — 3207 bytes — `8e881f0e36e96334…`
- `.opencode/skills/ascend310p-ccec-kb-ingestion/scripts/inventory_inputs.py` — 6586 bytes — `c3f2c88f6d1c3b49…`
- `.opencode/skills/ascend310p-ccec-kb-retrieval/SKILL.md` — 2705 bytes — `a46c7159b86c6ca3…`
- `.opencode/skills/ascend310p-ccec-operator-orchestrator/SKILL.md` — 9198 bytes — `b2324ebacf50fbf6…`
- `.opencode/skills/ascend310p-ccec-performance-optimization/SKILL.md` — 2424 bytes — `1be088657bb78fe0…`
- `.opencode/skills/ascend310p-ccec-profiling/SKILL.md` — 1558 bytes — `fdd612f5d7d699dd…`
- `.opencode/skills/ascend310p-ccec-regression/SKILL.md` — 1044 bytes — `e054fea6a747f5c3…`
- `.opencode/skills/ascend310p-ccec-release-audit/SKILL.md` — 1610 bytes — `c1953f36b989fe34…`
- `.opencode/skills/ascend310p-ccec-repo-context/SKILL.md` — 1739 bytes — `d72a7554b50589ae…`
- `.opencode/skills/ascend310p-ccec-semantic-analysis/SKILL.md` — 1408 bytes — `20148a3beca94866…`
- `.opencode/skills/ascend310p-ccec-test-generation/SKILL.md` — 1404 bytes — `090c1ba8738b7243…`
- `.operator-agent/runs/.gitkeep` — 0 bytes — `e3b0c44298fc1c14…`
- `AGENTS.md` — 2783 bytes — `1a4d3a3cec094408…`
- `PROMPT_EXAMPLES.md` — 2374 bytes — `7a182a0b6444f7be…`
- `README.md` — 7349 bytes — `aa077d3b96eb9ded…`
- `SOURCES.md` — 2123 bytes — `dc29a1875d1cdf7e…`
- `WORKFLOW_MAP.md` — 2479 bytes — `1d1841db587cd41f…`
- `contracts/DESIGN_SPEC.md` — 1002 bytes — `43b0112a8897b728…`
- `contracts/KB_EVIDENCE.md` — 1079 bytes — `ecd7eac3d7a10cd9…`
- `contracts/RELEASE_REPORT.md` — 840 bytes — `aa04e301c4656d88…`
- `contracts/RUN_STATE.md` — 433 bytes — `0421be6f6f21c96c…`
- `contracts/SEMANTIC_SPEC.md` — 805 bytes — `ff16eaa509d2bca6…`
- `contracts/STAGE_REPORT.md` — 1499 bytes — `091492b668e84355…`
- `contracts/TEST_PLAN.md` — 777 bytes — `0f84df585e0d4c5c…`
- `knowledge/README.md` — 1457 bytes — `0aa8725100e10fab…`
- `knowledge/_templates/api-card.md` — 546 bytes — `94e292566c0b02d9…`
- `knowledge/_templates/failure-case.md` — 415 bytes — `373cc6f94afe6c8a…`
- `knowledge/_templates/golden-operator.md` — 498 bytes — `8d50143408df40b9…`
- `knowledge/_templates/official-reference.md` — 287 bytes — `5d6429f044b4da19…`
- `knowledge/_templates/operator-pattern.md` — 424 bytes — `3e9376d0841d3044…`
- `knowledge/_templates/performance-case.md` — 562 bytes — `72e950cc9630449c…`
- `knowledge/_templates/project-convention.md` — 276 bytes — `8d8423e80a195c60…`
- `knowledge/api/README.md` — 109 bytes — `4a4aa1a98793527b…`
- `knowledge/failures/cross-generation-ccec-contamination.md` — 1002 bytes — `4c85042cf9cccf87…`
- `knowledge/golden-operators/README.md` — 92 bytes — `3d4009cb0b2cc6fd…`
- `knowledge/hardware/ascend310p/README.md` — 525 bytes — `92b50fac73c0a6a5…`
- `knowledge/index.md` — 76 bytes — `45242b9c84a0f2ee…`
- `knowledge/local-docs/README.md` — 453 bytes — `50614fefba964951…`
- `knowledge/official/README.md` — 124 bytes — `aa8d2646a52dcfdd…`
- `knowledge/official/ccec-davinci-bootstrap.md` — 1403 bytes — `d851f74a9e122846…`
- `knowledge/patterns/vector-gm-ub-baseline.md` — 1291 bytes — `78d4e1a9e8ab4fb9…`
- `knowledge/performance/README.md` — 114 bytes — `5e285ecfaffc83fe…`
- `knowledge/project/README.md` — 122 bytes — `d6941407abb15dd7…`
- `knowledge/project/target-contract.md` — 766 bytes — `c1169d8b53646ea5…`
- `knowledge/quarantine/README.md` — 203 bytes — `4fea3dee2f065b12…`
- `tools/discover_ccec.py` — 1099 bytes — `8ce5dc6048eaa4dd…`
- `tools/init_run.py` — 953 bytes — `34dba63980a67e2c…`
- `tools/kb_index.py` — 4345 bytes — `592f106b066fa4d5…`
- `tools/kb_lint.py` — 7875 bytes — `2d21b32cec025e0e…`
- `tools/kb_query.py` — 5794 bytes — `0388ee1827da2929…`
- `tools/self_check.py` — 4281 bytes — `7aca39059e8f483e…`
- `tools/validate_stage_report.py` — 3283 bytes — `044ef2042922c95d…`
