# CCE-C API / Intrinsic Cards

Only current Ascend 310P evidence may mark a card usable for code generation.
