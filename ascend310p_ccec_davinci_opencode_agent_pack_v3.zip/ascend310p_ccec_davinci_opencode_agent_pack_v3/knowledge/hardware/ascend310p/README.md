# Ascend 310P Hardware Knowledge

Store exact, locally verified hardware facts used by CCE-C design here, for example:

- usable AI Core count for the deployed product/configuration;
- UB/L1/L0 capacity and allocation restrictions;
- supported dtypes/instruction forms;
- DMA alignment/granularity constraints;
- Vector mask/repeat/stride rules;
- Cube tile/format constraints;
- pipeline/event resources.

Do not populate these from memory. Each hardware card should carry the CANN/CCE compiler version and evidence source.
