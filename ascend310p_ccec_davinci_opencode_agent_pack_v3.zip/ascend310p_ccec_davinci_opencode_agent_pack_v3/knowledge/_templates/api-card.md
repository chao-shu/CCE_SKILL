---
id: API-CCEC-REPLACE-ME
kind: api
title: ""
status: PROVISIONAL
soc: ["Ascend310P"]
architecture: ["DaVinci"]
cann: ["UNKNOWN"]
compiler: ["UNKNOWN"]
backend: ["cce-c"]
symbol: []
address_spaces: []
pipeline: []
dtype: []
trust: T6
compatibility: UNKNOWN
usable_for_codegen: false
verification: []
verified_on: ""
source: ""
tags: []
---

# Exact signature / syntax

# Parameter units

# Address-space constraints

# Alignment / repeat / stride / mask constraints

# Pipeline and synchronization

# Verification evidence

# Known limitations
