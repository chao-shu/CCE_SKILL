---
id: GOLDEN-CCEC-REPLACE-ME
kind: golden
title: ""
status: PROVISIONAL
soc: ["Ascend310P"]
architecture: ["DaVinci"]
cann: ["UNKNOWN"]
compiler: ["UNKNOWN"]
backend: ["cce-c"]
op_family: []
dtype: []
trust: T3
compatibility: UNKNOWN
usable_for_codegen: false
verification: []
build: NOT_RUN
accuracy: NOT_RUN
board: NOT_RUN
source_run: ""
source_paths: []
source: ""
---

# Semantic contract

# DaVinci design

# Intrinsics used

# Memory/event/tail strategy

# Verification

# Reuse boundaries
