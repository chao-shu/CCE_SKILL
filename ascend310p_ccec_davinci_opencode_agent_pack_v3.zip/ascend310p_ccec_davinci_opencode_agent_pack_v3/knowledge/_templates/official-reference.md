---
id: OFFICIAL-CCEC-REPLACE-ME
kind: official
title: ""
status: PROVISIONAL
soc: []
architecture: []
cann: []
backend: ["cce-c"]
trust: T2
compatibility: UNKNOWN
usable_for_codegen: false
source: ""
---

# Scope

# Relevant facts

# Exact target/version limitations

# Symbols covered
