---
id: PERF-CCEC-REPLACE-ME
kind: performance
title: ""
status: PROVISIONAL
soc: ["Ascend310P"]
architecture: ["DaVinci"]
cann: ["UNKNOWN"]
compiler: ["UNKNOWN"]
backend: ["cce-c"]
op_family: []
dtype: []
shape: []
trust: T3
compatibility: UNKNOWN
usable_for_codegen: false
source_run: ""
source_revision: ""
before_latency: ""
after_latency: ""
profiler_evidence: []
optimization_change: ""
decision: ""
source: ""
---

# Baseline

# Profiler bottleneck

# Single hypothesis

# Change

# Accuracy result

# Before/after measurement

# Decision and limitations
