---
id: PATTERN-CCEC-REPLACE-ME
kind: pattern
title: ""
status: PROVISIONAL
soc: ["Ascend310P"]
architecture: ["DaVinci"]
cann: ["UNKNOWN"]
backend: ["cce-c"]
op_family: []
dtype: []
trust: T6
compatibility: UNKNOWN
usable_for_codegen: false
source_goldens: []
source: ""
---

# Applicability

# Core partition

# GM/UB/L1/L0 plan

# DMA plan

# Vector/Cube plan

# Pipeline/event plan

# Tail plan

# Known counterexamples
