---
id: FAIL-CCEC-REPLACE-ME
kind: failure
title: ""
status: PROVISIONAL
soc: ["Ascend310P"]
architecture: ["DaVinci"]
cann: ["UNKNOWN"]
compiler: ["UNKNOWN"]
backend: ["cce-c"]
trust: T6
compatibility: UNKNOWN
usable_for_codegen: false
failure_class: UNKNOWN
error_signature: []
verified_fix: false
source_run: ""
source: ""
---

# Symptom

# Root cause

# Bad pattern

# Verified fix

# Scope / non-applicability
