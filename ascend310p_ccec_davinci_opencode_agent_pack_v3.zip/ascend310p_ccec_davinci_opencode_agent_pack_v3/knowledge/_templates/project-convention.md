---
id: PROJECT-CCEC-REPLACE-ME
kind: project
title: ""
status: VERIFIED
soc: ["Ascend310P"]
architecture: ["DaVinci"]
cann: ["UNKNOWN"]
backend: ["cce-c"]
trust: T1
compatibility: UNKNOWN
usable_for_codegen: false
source: ""
---

# Convention

# Evidence

# Files / commands
