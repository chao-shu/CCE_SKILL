# Local Documentation / Toolchain Evidence

Use this directory to record paths and hashes for the **actually installed** CANN/CCE compiler documentation, headers, builtin descriptions, samples or generated CCE-C material.

Do not copy proprietary documentation into this repository unless your licensing rules permit it. A metadata card containing local path, version, hash and relevant symbol names is sufficient for the Agent to retrieve it in-place.
