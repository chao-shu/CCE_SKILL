# Quarantine

Place original Ascend 310, A2/A3, other-product documents, cross-generation examples, external snippets and unverified model hypotheses here until current Ascend 310P evidence proves them.
