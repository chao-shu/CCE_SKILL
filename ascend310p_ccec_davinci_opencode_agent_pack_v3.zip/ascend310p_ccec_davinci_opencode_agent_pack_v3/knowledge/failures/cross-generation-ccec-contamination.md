---
id: FAIL-CCEC-CROSS-GENERATION-CONTAMINATION
kind: failure
title: "Cross-generation CCE Intrinsic contamination"
status: PROVISIONAL
soc: ["Ascend310P"]
architecture: ["DaVinci"]
cann: ["UNKNOWN"]
backend: ["cce-c"]
trust: T5
failure_class: CCE_INTRINSIC_NOT_AVAILABLE
verified_fix: false
source: "public CCE Intrinsic support matrices + architecture policy"
tags: ["compatibility", "intrinsic", "ascend310p", "ascend310", "a2", "a3"]
---

# Symptom

An Agent copies a CCE Intrinsic signature or hardware rule from original Ascend 310, A2/A3, or another product's documentation into an Ascend 310P `.cce` kernel.

# Risk

The intrinsic may be unavailable, have a different signature/constraint, or encode a hardware feature not present on the active Ascend 310P product and CANN/CCE version.

# Prevention

Require current compiler/repository or exact-compatible Ascend 310P evidence before code generation. Treat all other-product CCE Intrinsic documentation as concept-only until proven locally.
