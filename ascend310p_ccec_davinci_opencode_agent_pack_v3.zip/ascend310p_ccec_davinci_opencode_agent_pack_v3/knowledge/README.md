# Ascend 310P CCE-C Knowledge Base

This is a Markdown-first, provenance-aware KB for **Ascend 310P / DaVinci / CCE-C**.

The principal safety rule is **no cross-generation API contamination**.

Directories:

- `official/` normalized official references with exact version/product scope;
- `api/` verified CCE-C intrinsic/address-space/compiler cards;
- `golden-operators/` board-verified local kernels;
- `patterns/` generalized implementation patterns derived from verified kernels;
- `failures/` compiler/runtime/numerical/synchronization failure cases;
- `performance/` measured tuning cases;
- `project/` repository conventions;
- `local-docs/` notes/indexes for locally installed CANN/CCE docs and headers;
- `quarantine/` unverified or cross-generation material.

Trust levels:

- T0 current local compiler/build evidence
- T1 current repository working CCE-C
- T2 exact-compatible official docs
- T3 board-verified local Golden Operator
- T4 compatible same-generation official/generated material
- T5 other SoC/generation official material
- T6 external/model-memory material

Only cards with adequate verification may claim `usable_for_codegen: true`.

`tools/kb_lint.py` enforces code-generation authority, Golden Operator and verified performance gates. `tools/kb_query.py` uses exact dimension filters by default; `ANY`/`UNKNOWN` material is available only through an explicit conceptual-search option and remains unusable for code generation.
