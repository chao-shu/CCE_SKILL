---
id: PROJECT-TARGET-ASCEND310P-CCEC
kind: project
title: "Project target contract: Ascend 310P + DaVinci + CCE-C"
status: VERIFIED
soc: ["Ascend310P"]
architecture: ["DaVinci"]
cann: ["UNKNOWN"]
backend: ["cce-c"]
trust: T1
source: "project pack target contract"
tags: ["target", "backend", "davinci"]
---

# Convention

This workflow targets Ascend 310P hardware and direct CCE-C `.cce` operator development. Original Ascend 310, other products, and Ascend C are not default substitutes.

# Runtime requirement

The environment stage must still verify the actual detected SoC, compiler and repository conventions. If repository evidence contradicts the target contract, the orchestrator must surface the contradiction rather than silently migrating the backend.
