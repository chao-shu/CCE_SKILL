# Project Conventions

Repository-specific build, registration, `.cce` layout, compiler flags and invocation conventions.
