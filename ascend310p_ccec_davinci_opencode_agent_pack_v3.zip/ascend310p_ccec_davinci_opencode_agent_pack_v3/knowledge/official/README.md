# Official References

Normalize official sources here with exact CANN/CCE version, target product and compatibility scope.
