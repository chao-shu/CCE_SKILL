# Performance Cases

Record exact before/after measured cases; never generalize one result into a universal rule.
