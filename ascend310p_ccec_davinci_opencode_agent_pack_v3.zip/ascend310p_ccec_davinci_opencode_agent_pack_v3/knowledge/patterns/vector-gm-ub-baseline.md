---
id: PATTERN-CCEC-VECTOR-GM-UB-BASELINE
kind: pattern
title: "CCE-C Vector GM↔UB baseline skeleton"
status: PROVISIONAL
soc: ["Ascend310P"]
architecture: ["DaVinci"]
cann: ["UNKNOWN"]
backend: ["cce-c"]
op_family: ["ELEMENTWISE", "VECTOR"]
dtype: ["ANY"]
trust: T6
source: "architecture hypothesis; must be instantiated from current compiler/repository evidence"
tags: ["gm", "ub", "mte", "vector", "event", "tail"]
---

# Applicability

Candidate structure for elementwise/vector operators whose working set fits a verified UB tile.

# Conceptual dependency graph

```text
GM input
  ↓ data movement (verified GM→UB intrinsic/pipeline)
UB input
  ↓ synchronization
Vector compute
  ↓ synchronization
UB output
  ↓ data movement (verified UB→GM intrinsic/pipeline)
GM output
```

# Required specialization before use

The following MUST come from current Ascend 310P evidence:

- exact intrinsic names/signatures;
- transfer-length unit and alignment;
- vector lanes/mask semantics;
- repeat/stride ranges;
- pipeline identifiers;
- event IDs and reuse rules;
- UB size/alignment;
- block/core index semantics.

# Tail rule

Keep semantic valid length distinct from aligned/local length. Do not use aligned GM overread/overwrite unless the storage contract proves it valid.
